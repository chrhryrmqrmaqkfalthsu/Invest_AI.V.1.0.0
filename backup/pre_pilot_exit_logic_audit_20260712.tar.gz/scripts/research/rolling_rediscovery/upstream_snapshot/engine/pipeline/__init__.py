"""Rolling rediscovery pipeline package."""
