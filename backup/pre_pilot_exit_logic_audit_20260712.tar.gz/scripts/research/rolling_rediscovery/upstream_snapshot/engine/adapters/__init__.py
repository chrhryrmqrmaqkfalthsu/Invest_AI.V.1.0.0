"""Rolling rediscovery adapters package."""
