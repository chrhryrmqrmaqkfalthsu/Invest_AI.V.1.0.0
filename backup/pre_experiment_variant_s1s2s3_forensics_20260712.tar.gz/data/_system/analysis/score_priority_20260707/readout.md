# Score ↔ performance and priority rule validation

- verdict A: **SCORE_NEUTRAL**
- verdict C: **PRIORITY_BY_SCORE_HELPS**
- input: `/home/g3000kkw/kingmaker/data/_system/analysis/perday_perstock_20260707/per_trade_strategies.csv`
- OHLC: `/home/g3000kkw/kingmaker/data/_system/analysis/ohlc_snapshot_20260707`
- rows: all=43972, IS=31057, OOS=12915
- final_score = `entry_signal_score`; score_excess = `entry_signal_score - entry_signal_threshold`.

## A. Correlations
| split   | score_col    | target_col   |     n |     pearson |    spearman |
|:--------|:-------------|:-------------|------:|------------:|------------:|
| IS      | final_score  | s2_net       | 31057 |  0.0102871  |  0.00275804 |
| IS      | final_score  | s2_perday    | 31057 | -0.0156534  | -0.00213817 |
| IS      | final_score  | s2_MFE       | 31057 | -0.00903348 | -0.0302977  |
| IS      | final_score  | s2_MAE       | 31057 |  0.0140318  |  0.0213642  |
| IS      | final_score  | s2_win       | 31057 |  0.00820057 |  0.00121638 |
| IS      | score_excess | s2_net       | 31057 |  0.00320065 | -0.00891263 |
| IS      | score_excess | s2_perday    | 31057 | -0.0176277  | -0.0098504  |
| IS      | score_excess | s2_MFE       | 31057 |  0.00151792 | -0.0255372  |
| IS      | score_excess | s2_MAE       | 31057 | -0.0118868  | -0.00346983 |
| IS      | score_excess | s2_win       | 31057 | -0.00212456 | -0.0115607  |
| OOS     | final_score  | s2_net       | 12915 |  0.0234355  |  0.020427   |
| OOS     | final_score  | s2_perday    | 12915 |  0.00511766 |  0.0182387  |
| OOS     | final_score  | s2_MFE       | 12915 | -0.00228647 | -0.00610815 |
| OOS     | final_score  | s2_MAE       | 12915 |  0.0265997  |  0.0231714  |
| OOS     | final_score  | s2_win       | 12915 |  0.0196836  |  0.0194156  |
| OOS     | score_excess | s2_net       | 12915 |  0.0199508  |  0.0144131  |
| OOS     | score_excess | s2_perday    | 12915 |  0.00150882 |  0.0157091  |
| OOS     | score_excess | s2_MFE       | 12915 |  0.0173743  |  0.0196354  |
| OOS     | score_excess | s2_MAE       | 12915 | -0.012091   | -0.018871   |
| OOS     | score_excess | s2_win       | 12915 |  0.00972192 |  0.00827786 |

## A. Score quintiles, IS-defined bins
| split   | score_quintile   |    n |   score_min |   score_max |   score_mean |   excess_mean |   sum_net_pct |   avg_net_pct |   win_rate_pct |   avg_holding_days |   mean_net_per_day_pct |   avg_MFE_pct |   avg_MAE_pct |
|:--------|:-----------------|-----:|------------:|------------:|-------------:|--------------:|--------------:|--------------:|---------------:|-------------------:|-----------------------:|--------------:|--------------:|
| IS      | Q1_low           | 6212 |     1.50043 |     2.72965 |      2.26468 |      0.373957 |       5713.12 |      0.919691 |        52.1088 |            11.4385 |             0.00830146 |       9.96808 |      -7.10457 |
| IS      | Q2               | 6560 |     2.73007 |     3.25906 |      3.02682 |      0.591996 |       8573.54 |      1.30694  |        55.2134 |            11.8226 |             0.0862452  |       8.44958 |      -6.06689 |
| IS      | Q3               | 5862 |     3.25923 |     3.76207 |      3.5191  |      0.976525 |       7198.36 |      1.22797  |        55.1859 |            10.1293 |             0.0974977  |       8.87748 |      -6.14866 |
| IS      | Q4               | 6211 |     3.76213 |     4.81234 |      4.20425 |      1.53056  |       5754.21 |      0.926455 |        51.602  |            10.8968 |            -0.14227    |       9.25556 |      -6.69423 |
| IS      | Q5_high          | 6212 |     4.81237 |    18.0681  |      6.115   |      3.34377  |       6075.64 |      0.978049 |        52.8815 |            10.5852 |            -0.106576   |       8.6558  |      -6.37988 |
| OOS     | Q1_low           | 2212 |     1.50512 |     2.72968 |      2.2961  |      0.367812 |       7230.87 |      3.26893  |        60.2622 |            10.6356 |             0.23664    |      12.3847  |      -6.88986 |
| OOS     | Q2               | 2351 |     2.73028 |     3.25906 |      3.01403 |      0.616417 |       6077.49 |      2.58507  |        58.188  |            10.7188 |             0.160122   |      10.2884  |      -6.28824 |
| OOS     | Q3               | 2109 |     3.26143 |     3.76124 |      3.51995 |      0.992445 |       7115.11 |      3.37369  |        61.688  |            10.3253 |             0.27711    |      11.4979  |      -6.43195 |
| OOS     | Q4               | 2774 |     3.76236 |     4.81209 |      4.22473 |      1.59307  |       7874.68 |      2.83875  |        58.6878 |            10.3071 |             0.267048   |      11.2409  |      -6.77808 |
| OOS     | Q5_high          | 3469 |     4.81364 |    20.9433  |      6.41909 |      3.69846  |      13642.3  |      3.93263  |        62.2946 |            10.5065 |             0.310394   |      11.4214  |      -6.04065 |

## A. Q5 high minus Q1 low bootstrap
| split   | comparison           | metric    |   observed |   ci95_low |   ci95_mid |   ci95_high |   clusters |   n_q1 |   n_q5 |
|:--------|:---------------------|:----------|-----------:|-----------:|-----------:|------------:|-----------:|-------:|-------:|
| IS      | Q5_high_minus_Q1_low | s2_net    |  0.0583578 |  -0.861732 |  0.0420458 |    0.959675 |         93 |   6212 |   6212 |
| IS      | Q5_high_minus_Q1_low | s2_perday | -0.114878  |  -0.389408 | -0.118757  |    0.150548 |         93 |   6212 |   6212 |
| IS      | Q5_high_minus_Q1_low | s2_win    |  0.772698  |  -3.85762  |  0.749398  |    5.21059  |         93 |   6212 |   6212 |
| OOS     | Q5_high_minus_Q1_low | s2_net    |  0.663694  |  -0.777677 |  0.676798  |    2.19813  |         93 |   2212 |   3469 |
| OOS     | Q5_high_minus_Q1_low | s2_perday |  0.0737543 |  -0.239789 |  0.07781   |    0.38879  |         93 |   2212 |   3469 |
| OOS     | Q5_high_minus_Q1_low | s2_win    |  2.0324    |  -3.44792  |  2.17697   |    7.69828  |         93 |   2212 |   3469 |

## B. Threshold excess cuts, IS-defined
| split   | cut_label   |   keep_fraction_is_design |   score_excess_cut_from_IS |     n |   n_base |   kept_pct |   sum_net_pct |   avg_net_pct |   win_rate_pct |   avg_holding_days |   mean_net_per_day_pct |   median_net_per_day_pct |   avg_MDD_proxy_MAE_pct |
|:--------|:------------|--------------------------:|---------------------------:|------:|---------:|-----------:|--------------:|--------------:|---------------:|-------------------:|-----------------------:|-------------------------:|------------------------:|
| IS      | keep_100pct |                       1   |                 nan        | 31057 |    31057 |   100      |       33314.9 |      1.0727   |        53.3986 |            10.9935 |             -0.0114893 |                0.0756304 |                -6.47794 |
| OOS     | keep_100pct |                       1   |                 nan        | 12915 |    12915 |   100      |       41940.4 |      3.24742  |        60.3252 |            10.4949 |              0.255661  |                0.258805  |                -6.45346 |
| IS      | keep_80pct  |                       0.8 |                   0.370286 | 24907 |    31057 |    80.1977 |       27642.1 |      1.10981  |        53.3344 |            10.9042 |             -0.0201887 |                0.0760143 |                -6.39321 |
| OOS     | keep_80pct  |                       0.8 |                   0.370286 | 10637 |    12915 |    82.3616 |       35301   |      3.3187   |        60.44   |            10.4573 |              0.261555  |                0.264148  |                -6.46922 |
| IS      | keep_60pct  |                       0.6 |                   0.716155 | 18634 |    31057 |    59.9994 |       20339.5 |      1.09153  |        52.9838 |            10.7773 |             -0.0338389 |                0.0725324 |                -6.49084 |
| OOS     | keep_60pct  |                       0.6 |                   0.716155 |  8485 |    12915 |    65.6988 |       29217.3 |      3.44341  |        60.6953 |            10.4113 |              0.276829  |                0.27539   |                -6.54189 |
| IS      | keep_40pct  |                       0.4 |                   1.22646  | 12423 |    31057 |    40.0006 |       12026.1 |      0.968054 |        52.6765 |            10.4624 |             -0.0765718 |                0.0693446 |                -6.60607 |
| OOS     | keep_40pct  |                       0.4 |                   1.22646  |  6220 |    12915 |    48.1611 |       21200.2 |      3.4084   |        60.209  |            10.3529 |              0.279963  |                0.268931  |                -6.60499 |
| IS      | keep_20pct  |                       0.2 |                   2.16077  |  6212 |    31057 |    20.0019 |        6480.1 |      1.04316  |        52.6079 |            10.4776 |             -0.11488   |                0.0792024 |                -6.62858 |
| OOS     | keep_20pct  |                       0.2 |                   2.16077  |  3570 |    12915 |    27.6423 |       13801.1 |      3.86586  |        61.0084 |            10.4076 |              0.330304  |                0.308413  |                -6.49842 |

## C. S2 K=20 priority portfolio
| priority_rule                     |   K |   total_signals |   realized_trades |   skipped_signals |   skip_rate_pct |   final_multiplier |   CAGR_pct |   MDD_pct |   Sharpe_daily_ann |   avg_active_positions |   max_active_positions |   avg_slot_occupancy_pct |   accepted_avg_net_pct |   accepted_win_rate_pct |   accepted_avg_final_score |   accepted_avg_score_excess |
|:----------------------------------|----:|----------------:|------------------:|------------------:|----------------:|-------------------:|-----------:|----------:|-------------------:|-----------------------:|-----------------------:|-------------------------:|-----------------------:|------------------------:|---------------------------:|----------------------------:|
| P1_score_high_first               |  20 |           12915 |               726 |             12189 |         94.3786 |            2.26947 |    72.2678 |  -21.9627 |            1.84165 |                19.9894 |                     20 |                  99.9468 |                2.56765 |                 60.1928 |                    7.68842 |                     5.01006 |
| P2_score_low_first                |  20 |           12915 |               667 |             12248 |         94.8355 |            2.07963 |    62.565  |  -24.6134 |            1.55965 |                19.9814 |                     20 |                  99.9069 |                2.69746 |                 59.0705 |                    2.12579 |                     0.32241 |
| P3_random_seed42                  |  20 |           12915 |               677 |             12238 |         94.758  |            1.80063 |    47.7436 |  -27.8485 |            1.30907 |                19.9867 |                     20 |                  99.9335 |                1.91171 |                 56.4254 |                    4.09612 |                     1.62132 |
| P4_candidate_IS_perday_high_first |  20 |           12915 |               841 |             12074 |         93.4882 |            2.36798 |    77.1948 |  -30.076  |            1.66449 |                19.9947 |                     20 |                  99.9734 |                2.29599 |                 67.4197 |                    3.96311 |                     1.57104 |

## Files
- `/tmp/score_priority_20260707_1904/readout.md`
- `/home/g3000kkw/kingmaker/data/_system/analysis/score_priority_20260707/readout.md`
- `/tmp/score_priority_20260707_1904/score_correlations.csv`
- `/home/g3000kkw/kingmaker/data/_system/analysis/score_priority_20260707/score_correlations.csv`
- `/tmp/score_priority_20260707_1904/score_quintile.csv`
- `/home/g3000kkw/kingmaker/data/_system/analysis/score_priority_20260707/score_quintile.csv`
- `/tmp/score_priority_20260707_1904/score_quintile_bootstrap_diff.csv`
- `/home/g3000kkw/kingmaker/data/_system/analysis/score_priority_20260707/score_quintile_bootstrap_diff.csv`
- `/tmp/score_priority_20260707_1904/threshold_cuts.csv`
- `/home/g3000kkw/kingmaker/data/_system/analysis/score_priority_20260707/threshold_cuts.csv`
- `/tmp/score_priority_20260707_1904/priority_portfolio.csv`
- `/home/g3000kkw/kingmaker/data/_system/analysis/score_priority_20260707/priority_portfolio.csv`
- `/tmp/score_priority_20260707_1904/priority_equity_curves.csv`
- `/home/g3000kkw/kingmaker/data/_system/analysis/score_priority_20260707/priority_equity_curves.csv`
- `/tmp/score_priority_20260707_1904/priority_accepted_trades.csv`
- `/home/g3000kkw/kingmaker/data/_system/analysis/score_priority_20260707/priority_accepted_trades.csv`
- `/tmp/score_priority_20260707_1904/summary.json`
- `/home/g3000kkw/kingmaker/data/_system/analysis/score_priority_20260707/summary.json`
