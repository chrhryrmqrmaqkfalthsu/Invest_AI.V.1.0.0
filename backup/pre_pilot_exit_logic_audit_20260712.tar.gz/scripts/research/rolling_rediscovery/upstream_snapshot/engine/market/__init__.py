"""Rolling rediscovery market package."""
