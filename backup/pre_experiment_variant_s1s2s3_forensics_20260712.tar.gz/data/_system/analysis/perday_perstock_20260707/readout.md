# Frozen per-day / per-stock exit analysis

- input: `/home/g3000kkw/kingmaker/data/_system/analysis/oos_reproduce_frozen_20260707/oos_trades_frozen.csv`
- OHLC snapshot: `/home/g3000kkw/kingmaker/data/_system/analysis/ohlc_snapshot_20260707`
- rows: all=43972, IS=31057, OOS=12915
- TP2 exact net after cost: 1.697000%
- replay_errors: 0
- verdict A: **PERDAY_REVERSES**
- verdict B: **PERSTOCK_ASSIGN_HELPS**

## A. OOS strategy per-day ranking
| split   | strategy                         |     n |   sum_net_pct |   avg_net_pct |   mean_net_per_day_pct |   median_net_per_day_pct |   avg_holding_days |   win_rate_pct |
|:--------|:---------------------------------|------:|--------------:|--------------:|-----------------------:|-------------------------:|-------------------:|---------------:|
| OOS     | S3_tp2_2d_then_no_take_profit    | 12915 |       13134.2 |       1.01697 |               0.688014 |                 0.8485   |            5.39179 |        80.4878 |
| OOS     | S1_original_take_profit_included | 12915 |       40031.9 |       3.09964 |               0.521908 |                 0.299638 |            9.82733 |        61.3395 |
| OOS     | S2_no_take_profit_solo           | 12915 |       41940.4 |       3.24742 |               0.255661 |                 0.258805 |           10.4949  |        60.3252 |

## A. OOS net/day bootstrap CI
| strategy                         |   observed |   ci95_low |   ci95_mid |   ci95_high |   clusters |   n_trades |
|:---------------------------------|-----------:|-----------:|-----------:|------------:|-----------:|-----------:|
| S1_original_take_profit_included |   0.521908 |   0.356506 |   0.521131 |    0.691562 |         93 |      12915 |
| S2_no_take_profit_solo           |   0.255661 |   0.097969 |   0.256331 |    0.410639 |         93 |      12915 |
| S3_tp2_2d_then_no_take_profit    |   0.688014 |   0.600021 |   0.689216 |    0.768865 |         93 |      12915 |

## A. S3 pairwise per-day diff bootstrap
| diff        |   observed |   ci95_low |   ci95_mid |   ci95_high |   clusters |   n_trades |
|:------------|-----------:|-----------:|-----------:|------------:|-----------:|-----------:|
| S3_minus_S1 |   0.166105 |  0.0317842 |   0.168079 |    0.290594 |         93 |      12915 |
| S3_minus_S2 |   0.432352 |  0.328172  |   0.431979 |    0.534904 |         93 |      12915 |

## A. Q1~Q4 OOS per-day decomposition
| quadrant                    |    n |   s1_mean_perday |   s2_mean_perday |   s3_mean_perday |   s3_minus_s2_mean_perday |   s3_minus_s2_sum_net_pct |   s1_avg_net |   s2_avg_net |   s3_avg_net |   s1_avg_hold |   s2_avg_hold |   s3_avg_hold |   pct_oos |
|:----------------------------|-----:|-----------------:|-----------------:|-----------------:|--------------------------:|--------------------------:|-------------:|-------------:|-------------:|--------------:|--------------:|--------------:|----------:|
| Q1_tp2_hit_notp_win         | 5212 |          2.36831 |         1.85882  |         1.44401  |                  -0.41481 |                  -53232.2 |     11.2378  |     11.9104  |      1.697   |       8.76458 |       9.94071 |       1.29816 |   40.3562 |
| Q2_tp2_hit_notp_loss_rescue | 2604 |         -1.30387 |        -1.50014  |         1.47445  |                   2.97459 |                   24425.9 |     -6.92024 |     -7.68315 |      1.697   |       8.99078 |       9.27343 |       1.26229 |   20.1626 |
| Q3_no_tp2_notp_win          | 2579 |          0.91108 |         0.828509 |         0.828509 |                   0       |                       0   |      8.00122 |      8.31427 |      8.31427 |      11.9236  |      12.5297  |      12.5297  |   19.969  |
| Q4_no_tp2_notp_loss         | 2520 |         -1.80856 |        -1.83202  |        -1.83202  |                   0       |                       0   |     -8.39453 |     -8.56034 |     -8.56034 |      10.7444  |      10.8206  |      10.8206  |   19.5122 |

## B. OOS assignment comparison
| portfolio                        | scope                 |     n |   sum_net_pct |   avg_net_pct |   mean_net_per_day_pct |   median_net_per_day_pct |   avg_holding_days |   win_rate_pct |
|:---------------------------------|:----------------------|------:|--------------:|--------------:|-----------------------:|-------------------------:|-------------------:|---------------:|
| uniform_S1_original_tp           | eligible_only         | 12915 |       40031.9 |       3.09964 |               0.521908 |                 0.299638 |            9.82733 |        61.3395 |
| uniform_S2_no_take_profit        | eligible_only         | 12915 |       41940.4 |       3.24742 |               0.255661 |                 0.258805 |           10.4949  |        60.3252 |
| uniform_S3_tp2_then_notp         | eligible_only         | 12915 |       13134.2 |       1.01697 |               0.688014 |                 0.8485   |            5.39179 |        80.4878 |
| IS_best_per_candidate_assignment | eligible_only         | 12915 |       14509.7 |       1.12347 |               0.732248 |                 0.8485   |            5.52149 |        78.9547 |
| uniform_S1_original_tp           | all_watch_s2_fallback | 12915 |       40031.9 |       3.09964 |               0.521908 |                 0.299638 |            9.82733 |        61.3395 |
| uniform_S2_no_take_profit        | all_watch_s2_fallback | 12915 |       41940.4 |       3.24742 |               0.255661 |                 0.258805 |           10.4949  |        60.3252 |
| uniform_S3_tp2_then_notp         | all_watch_s2_fallback | 12915 |       13134.2 |       1.01697 |               0.688014 |                 0.8485   |            5.39179 |        80.4878 |
| IS_best_per_candidate_assignment | all_watch_s2_fallback | 12915 |       14509.7 |       1.12347 |               0.732248 |                 0.8485   |            5.52149 |        78.9547 |

## B. IS/OOS best-exit stability
- eligible candidates: 93
- WATCH candidates: 0
- match: 71/93 = 76.34%
- random baseline: 33.33%
- p-value greater than random: 2.53747e-17
- best uniform by eligible OOS net/day: S3

## Files
- `/tmp/perday_perstock_exit_20260707_1715/strategy_perday.csv`
- `/home/g3000kkw/kingmaker/data/_system/analysis/perday_perstock_20260707/strategy_perday.csv`
- `/tmp/perday_perstock_exit_20260707_1715/strategy_perday_bootstrap_ci.csv`
- `/home/g3000kkw/kingmaker/data/_system/analysis/perday_perstock_20260707/strategy_perday_bootstrap_ci.csv`
- `/tmp/perday_perstock_exit_20260707_1715/quadrant_perday_summary.csv`
- `/home/g3000kkw/kingmaker/data/_system/analysis/perday_perstock_20260707/quadrant_perday_summary.csv`
- `/tmp/perday_perstock_exit_20260707_1715/per_candidate_best_exit.csv`
- `/home/g3000kkw/kingmaker/data/_system/analysis/perday_perstock_20260707/per_candidate_best_exit.csv`
- `/tmp/perday_perstock_exit_20260707_1715/assignment_oos.csv`
- `/home/g3000kkw/kingmaker/data/_system/analysis/perday_perstock_20260707/assignment_oos.csv`
- `/tmp/perday_perstock_exit_20260707_1715/assignment_oos_summary.csv`
- `/home/g3000kkw/kingmaker/data/_system/analysis/perday_perstock_20260707/assignment_oos_summary.csv`
- `/tmp/perday_perstock_exit_20260707_1715/per_trade_strategies.csv`
- `/home/g3000kkw/kingmaker/data/_system/analysis/perday_perstock_20260707/per_trade_strategies.csv`
- `/tmp/perday_perstock_exit_20260707_1715/summary.json`
- `/home/g3000kkw/kingmaker/data/_system/analysis/perday_perstock_20260707/summary.json`
- `/tmp/perday_perstock_exit_20260707_1715/readout.md`
- `/home/g3000kkw/kingmaker/data/_system/analysis/perday_perstock_20260707/readout.md`
