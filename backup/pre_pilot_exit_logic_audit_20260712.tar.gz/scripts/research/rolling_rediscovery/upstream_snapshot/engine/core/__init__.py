"""Rolling rediscovery core package."""
