from __future__ import annotations

import json
import math
import os
import re
import shutil
import time
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

SEED = 42
N_BOOT = 10000
COMMISSION_RATE = 0.003
TRADING_DAYS_PER_YEAR = 252
np.random.seed(SEED)

ROOT = Path.cwd()
OUT_DIR = Path(os.environ["EXITVAR_OUT_DIR"]).resolve()
PERSIST_DIR = (ROOT / os.environ["EXITVAR_PERSIST_DIR"]).resolve()
TRADE_PATH = ROOT / "data/_system/analysis/perday_perstock_20260707/per_trade_strategies.csv"
CAND_PATH = ROOT / "data/_system/analysis/perday_perstock_20260707/per_candidate_best_exit.csv"
SNAP_DIR = ROOT / "data/_system/analysis/ohlc_snapshot_20260707"
OOS_START = pd.Timestamp("2025-01-01")
OOS_END = pd.Timestamp("2026-07-02")
PORT_K = [20, 10]
TRAIL_PCTS = [1.0, 1.5, 2.0]


def safe_name(ticker: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", str(ticker).upper())


def safe_float(x: Any, default: float = np.nan) -> float:
    try:
        if x is None or x == "":
            return default
        y = float(x)
        return y if math.isfinite(y) else default
    except Exception:
        return default


def date_str(x: Any) -> str:
    try:
        return pd.Timestamp(x).strftime("%Y-%m-%d")
    except Exception:
        return str(x)[:10]


def compute_net_pct(entry_price: float, exit_price: float) -> float:
    if entry_price <= 0 or exit_price <= 0:
        return np.nan
    gross = (exit_price - entry_price) / entry_price
    commission = (entry_price + exit_price) * (COMMISSION_RATE / 2.0) / entry_price
    return float((gross - commission) * 100.0)


def load_ohlc(ticker: str) -> pd.DataFrame:
    p = SNAP_DIR / f"{safe_name(ticker)}_ohlcv.csv"
    if not p.exists():
        raise RuntimeError(f"snapshot missing: {ticker} {p}")
    df = pd.read_csv(p)
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date"]).sort_values("Date").reset_index(drop=True)
    return df


def find_idx(df: pd.DataFrame, d: Any) -> int | None:
    try:
        key = pd.Timestamp(d).strftime("%Y-%m-%d")
        hit = df.index[df["Date"].dt.strftime("%Y-%m-%d").eq(key)]
        return int(hit[0]) if len(hit) else None
    except Exception:
        return None


def close_position(row: pd.Series) -> float:
    high = safe_float(row.get("High"))
    low = safe_float(row.get("Low"))
    close = safe_float(row.get("Close"))
    if not math.isfinite(high) or not math.isfinite(low) or not math.isfinite(close) or high <= low:
        return 0.5
    return float((close - low) / (high - low))


def volume_ratio(df: pd.DataFrame, idx: int, window: int = 20) -> float:
    vol = safe_float(df.iloc[idx].get("Volume"), np.nan)
    if not math.isfinite(vol):
        return np.nan
    start = max(0, idx - window)
    prev = pd.to_numeric(df.iloc[start:idx].get("Volume"), errors="coerce")
    avg = float(prev.mean()) if len(prev.dropna()) else np.nan
    if not math.isfinite(avg) or avg <= 0:
        return 1.0
    return float(vol / avg)


def path_mae_mfe(df: pd.DataFrame, entry_idx: int, exit_idx: int, entry_price: float) -> tuple[float, float]:
    if exit_idx < entry_idx:
        exit_idx = entry_idx
    sub = df.iloc[entry_idx:exit_idx + 1]
    lows = pd.to_numeric(sub["Low"], errors="coerce")
    highs = pd.to_numeric(sub["High"], errors="coerce")
    mae = float((lows.min() - entry_price) / entry_price * 100.0) if len(lows.dropna()) else 0.0
    mfe = float((highs.max() - entry_price) / entry_price * 100.0) if len(highs.dropna()) else 0.0
    return mae, mfe


def s2_result(r: pd.Series) -> dict[str, Any]:
    return {
        "net": safe_float(r.get("s2_net")),
        "hold": int(max(1, safe_float(r.get("s2_hold"), 1))),
        "exit_date": date_str(r.get("s2_exit_date")),
        "exit_price": safe_float(r.get("s2_exit_price")),
        "exit_reason": str(r.get("s2_exit_reason")),
        "MAE": safe_float(r.get("s2_MAE", r.get("MAE"))),
        "MFE": safe_float(r.get("s2_MFE", r.get("MFE"))),
        "tp2_hit_2d": bool(r.get("tp2_hit_2d")),
        "tp2_hit_date": r.get("tp2_hit_date", ""),
    }


def s3_result(r: pd.Series) -> dict[str, Any]:
    return {
        "net": safe_float(r.get("s3_net")),
        "hold": int(max(1, safe_float(r.get("s3_hold"), 1))),
        "exit_date": date_str(r.get("s3_exit_date")),
        "exit_price": safe_float(r.get("s3_exit_price")),
        "exit_reason": str(r.get("s3_exit_reason")),
        "MAE": safe_float(r.get("s3_MAE", r.get("MAE"))),
        "MFE": safe_float(r.get("s3_MFE", r.get("MFE"))),
        "tp2_hit_2d": bool(r.get("tp2_hit_2d")),
        "tp2_hit_date": r.get("tp2_hit_date", ""),
    }


def locate_tp2(df: pd.DataFrame, entry_idx: int, entry_price: float) -> tuple[bool, int | None]:
    target = entry_price * 1.02
    for j in [entry_idx, entry_idx + 1]:
        if j >= len(df):
            continue
        high = safe_float(df.iloc[j].get("High"))
        if math.isfinite(high) and high >= target:
            return True, j
    return False, None


def fallback_or_event(r: pd.Series, df: pd.DataFrame, event_idx: int | None, event_price: float | None, reason: str) -> dict[str, Any]:
    s2 = s2_result(r)
    if event_idx is None or event_price is None or not math.isfinite(event_price):
        return s2
    s2_idx = find_idx(df, r.get("s2_exit_date"))
    # Same-date collision falls back to S2 to preserve original daily-bar conflict ordering.
    if s2_idx is not None and event_idx >= s2_idx:
        return s2
    entry_idx = find_idx(df, r.get("entry_date"))
    entry_price = safe_float(r.get("entry_price"))
    if entry_idx is None or not math.isfinite(entry_price):
        return s2
    mae, mfe = path_mae_mfe(df, entry_idx, event_idx, entry_price)
    return {
        "net": compute_net_pct(entry_price, float(event_price)),
        "hold": int(max(1, event_idx - entry_idx + 1)),
        "exit_date": date_str(df.iloc[event_idx]["Date"]),
        "exit_price": float(event_price),
        "exit_reason": reason,
        "MAE": mae,
        "MFE": mfe,
        "tp2_hit_2d": True,
        "tp2_hit_date": date_str(df.iloc[event_idx]["Date"]),
    }


def variant_trail(r: pd.Series, df: pd.DataFrame, trail_pct: float) -> dict[str, Any]:
    entry_idx = find_idx(df, r.get("entry_date"))
    entry_price = safe_float(r.get("entry_price"))
    s2 = s2_result(r)
    if entry_idx is None or not math.isfinite(entry_price) or entry_price <= 0:
        return s2
    hit, hit_idx = locate_tp2(df, entry_idx, entry_price)
    if not hit or hit_idx is None:
        return s2
    s2_idx = find_idx(df, r.get("s2_exit_date"))
    end_idx = s2_idx if s2_idx is not None else min(len(df) - 1, entry_idx + int(max(1, safe_float(r.get("s2_hold"), 1))))
    highwater = max(entry_price * 1.02, safe_float(df.iloc[hit_idx].get("High"), entry_price * 1.02))
    stop_price = highwater * (1.0 - trail_pct / 100.0)
    event_idx = None
    event_price = None
    # target/trailing activation uses the hit day high but protective stop is checked from next bar to avoid daily-bar intraday ordering ambiguity.
    for j in range(hit_idx + 1, end_idx + 1):
        row = df.iloc[j]
        high = safe_float(row.get("High"))
        low = safe_float(row.get("Low"))
        if math.isfinite(high) and high > highwater:
            highwater = high
            stop_price = highwater * (1.0 - trail_pct / 100.0)
        if math.isfinite(low) and low <= stop_price:
            event_idx = j
            event_price = stop_price
            break
    return fallback_or_event(r, df, event_idx, event_price, f"tp2_trail_{trail_pct:.1f}pct")


def variant_target(r: pd.Series, df: pd.DataFrame, floor: bool = False) -> dict[str, Any]:
    entry_idx = find_idx(df, r.get("entry_date"))
    entry_price = safe_float(r.get("entry_price"))
    s2 = s2_result(r)
    if entry_idx is None or not math.isfinite(entry_price) or entry_price <= 0:
        return s2
    hit, hit_idx = locate_tp2(df, entry_idx, entry_price)
    if not hit or hit_idx is None:
        return s2
    target = entry_price * 1.03
    s2_idx = find_idx(df, r.get("s2_exit_date"))
    end_idx = s2_idx if s2_idx is not None else min(len(df) - 1, entry_idx + int(max(1, safe_float(r.get("s2_hold"), 1))))
    # +3 target can be counted on the hit day because it necessarily occurs after crossing +2 within the same daily range.
    for j in range(hit_idx, end_idx + 1):
        row = df.iloc[j]
        high = safe_float(row.get("High"))
        low = safe_float(row.get("Low"))
        if math.isfinite(high) and high >= target:
            return fallback_or_event(r, df, j, target, "tp2_target_3pct")
        if floor and j > hit_idx and math.isfinite(low) and low <= entry_price:
            return fallback_or_event(r, df, j, entry_price, "tp2_target_floor_breakeven")
    return s2


def variant_momentum(r: pd.Series, df: pd.DataFrame) -> dict[str, Any]:
    entry_idx = find_idx(df, r.get("entry_date"))
    entry_price = safe_float(r.get("entry_price"))
    s2 = s2_result(r)
    if entry_idx is None or not math.isfinite(entry_price) or entry_price <= 0:
        return s2
    hit, hit_idx = locate_tp2(df, entry_idx, entry_price)
    if not hit or hit_idx is None:
        return s2
    cp = close_position(df.iloc[hit_idx])
    vr = volume_ratio(df, hit_idx)
    strong = bool(cp >= 0.5 and (math.isfinite(vr) and vr >= 1.0))
    if strong:
        out = dict(s2)
        out["momentum_strong"] = True
        out["momentum_close_position"] = cp
        out["momentum_volume_ratio"] = vr
        return out
    target2 = entry_price * 1.02
    mae, mfe = path_mae_mfe(df, entry_idx, hit_idx, entry_price)
    return {
        "net": compute_net_pct(entry_price, target2),
        "hold": int(max(1, hit_idx - entry_idx + 1)),
        "exit_date": date_str(df.iloc[hit_idx]["Date"]),
        "exit_price": float(target2),
        "exit_reason": "tp2_momentum_weak_exit",
        "MAE": mae,
        "MFE": mfe,
        "tp2_hit_2d": True,
        "tp2_hit_date": date_str(df.iloc[hit_idx]["Date"]),
        "momentum_strong": False,
        "momentum_close_position": cp,
        "momentum_volume_ratio": vr,
    }


def build_variant_table(base: pd.DataFrame) -> pd.DataFrame:
    ohlc_cache: dict[str, pd.DataFrame] = {}
    rows = []
    variant_names = ["S2_no_take_profit", "S3_tp2_exit", "S3_trail_1.0", "S3_trail_1.5", "S3_trail_2.0", "S3_target_3pct", "S3_target_floor", "S3_momentum"]
    for i, r in base.iterrows():
        ticker = str(r.get("ticker")).upper()
        if ticker not in ohlc_cache:
            ohlc_cache[ticker] = load_ohlc(ticker)
        df = ohlc_cache[ticker]
        results = {
            "S2_no_take_profit": s2_result(r),
            "S3_tp2_exit": s3_result(r),
            "S3_trail_1.0": variant_trail(r, df, 1.0),
            "S3_trail_1.5": variant_trail(r, df, 1.5),
            "S3_trail_2.0": variant_trail(r, df, 2.0),
            "S3_target_3pct": variant_target(r, df, floor=False),
            "S3_target_floor": variant_target(r, df, floor=True),
            "S3_momentum": variant_momentum(r, df),
        }
        for name in variant_names:
            res = results[name]
            hold = int(max(1, safe_float(res.get("hold"), 1)))
            net = safe_float(res.get("net"))
            rows.append({
                "trade_row_id": int(r.get("trade_row_id")),
                "candidate_id": r.get("candidate_id"),
                "ticker": ticker,
                "split": str(r.get("split")).upper(),
                "stage": r.get("stage"),
                "signal_date": date_str(r.get("signal_date")),
                "entry_date": date_str(r.get("entry_date")),
                "entry_price": safe_float(r.get("entry_price")),
                "strategy": name,
                "exit_date": res.get("exit_date"),
                "exit_price": safe_float(res.get("exit_price")),
                "exit_reason": res.get("exit_reason"),
                "net_pct": net,
                "holding_days": hold,
                "net_per_day_pct": net / hold if hold else np.nan,
                "win": bool(net > 0),
                "MAE": safe_float(res.get("MAE")),
                "MFE": safe_float(res.get("MFE")),
                "tp2_hit_2d": bool(res.get("tp2_hit_2d", False)),
                "tp2_hit_date": res.get("tp2_hit_date", ""),
                "quadrant": r.get("quadrant"),
                "entry_signal_score": safe_float(r.get("entry_signal_score")),
                "candidate_priority_seed": safe_float(r.get("s2_perday")),
                "momentum_strong": res.get("momentum_strong", np.nan),
                "momentum_close_position": res.get("momentum_close_position", np.nan),
                "momentum_volume_ratio": res.get("momentum_volume_ratio", np.nan),
            })
        if (i + 1) % 5000 == 0:
            print(f"[VARIANT {i+1}/{len(base)}]", flush=True)
    return pd.DataFrame(rows)


def cluster_boot_ci(df: pd.DataFrame, value_col: str, seed: int = SEED, n_boot: int = N_BOOT) -> dict[str, Any]:
    tmp = df[["candidate_id", value_col]].dropna().copy()
    clusters = tmp["candidate_id"].astype(str).unique()
    groups = {c: tmp.loc[tmp["candidate_id"].astype(str).eq(c), value_col].to_numpy(dtype=float) for c in clusters}
    rng = np.random.default_rng(seed)
    vals = np.empty(n_boot)
    for i in range(n_boot):
        sampled = rng.choice(clusters, size=len(clusters), replace=True)
        arr = np.concatenate([groups[c] for c in sampled])
        vals[i] = arr.mean()
    lo, mid, hi = np.percentile(vals, [2.5, 50, 97.5])
    return {"observed": float(tmp[value_col].mean()), "ci95_low": float(lo), "ci95_mid": float(mid), "ci95_high": float(hi), "clusters": int(len(clusters)), "n_trades": int(len(tmp)), "n_boot": n_boot, "seed": seed}


def metric_table(trades: pd.DataFrame, split: str) -> pd.DataFrame:
    d = trades[trades["split"].eq(split)].copy()
    rows = []
    for s, g in d.groupby("strategy"):
        rows.append({
            "split": split,
            "strategy": s,
            "n": int(len(g)),
            "sum_net_pct": float(g["net_pct"].sum()),
            "avg_net_pct": float(g["net_pct"].mean()),
            "median_net_pct": float(g["net_pct"].median()),
            "win_rate_pct": float(g["win"].mean() * 100.0),
            "avg_holding_days": float(g["holding_days"].mean()),
            "mean_net_per_day_pct": float(g["net_per_day_pct"].mean()),
            "median_net_per_day_pct": float(g["net_per_day_pct"].median()),
            "avg_MAE_pct": float(g["MAE"].mean()),
            "avg_MFE_pct": float(g["MFE"].mean()),
        })
    order = ["S2_no_take_profit", "S3_tp2_exit", "S3_trail_1.0", "S3_trail_1.5", "S3_trail_2.0", "S3_target_3pct", "S3_target_floor", "S3_momentum"]
    out = pd.DataFrame(rows)
    out["order"] = out["strategy"].map({v: i for i, v in enumerate(order)}).fillna(999)
    return out.sort_values("order").drop(columns=["order"])


def bootstrap_tables(trades: pd.DataFrame, split: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    d = trades[trades["split"].eq(split)].copy()
    ci_rows = []
    diff_rows = []
    s2 = d[d["strategy"].eq("S2_no_take_profit")][["trade_row_id", "candidate_id", "net_pct", "net_per_day_pct"]].rename(columns={"net_pct": "s2_net", "net_per_day_pct": "s2_perday"})
    for s, g in d.groupby("strategy"):
        ci_net = cluster_boot_ci(g, "net_pct")
        ci_day = cluster_boot_ci(g, "net_per_day_pct")
        ci_rows.append({"split": split, "strategy": s, "mean_net_observed": ci_net["observed"], "mean_net_ci_low": ci_net["ci95_low"], "mean_net_ci_mid": ci_net["ci95_mid"], "mean_net_ci_high": ci_net["ci95_high"], "mean_perday_observed": ci_day["observed"], "mean_perday_ci_low": ci_day["ci95_low"], "mean_perday_ci_mid": ci_day["ci95_mid"], "mean_perday_ci_high": ci_day["ci95_high"], "clusters": ci_net["clusters"], "n_trades": ci_net["n_trades"]})
        if s != "S2_no_take_profit":
            gg = g[["trade_row_id", "candidate_id", "net_pct", "net_per_day_pct"]].merge(s2, on=["trade_row_id", "candidate_id"], how="inner")
            gg["diff_net_vs_s2"] = gg["net_pct"] - gg["s2_net"]
            gg["diff_perday_vs_s2"] = gg["net_per_day_pct"] - gg["s2_perday"]
            dn = cluster_boot_ci(gg, "diff_net_vs_s2")
            dd = cluster_boot_ci(gg, "diff_perday_vs_s2")
            diff_rows.append({"split": split, "strategy": s, "diff_net_vs_s2": dn["observed"], "diff_net_ci_low": dn["ci95_low"], "diff_net_ci_high": dn["ci95_high"], "diff_perday_vs_s2": dd["observed"], "diff_perday_ci_low": dd["ci95_low"], "diff_perday_ci_high": dd["ci95_high"], "clusters": dn["clusters"], "n_trades": dn["n_trades"]})
    return pd.DataFrame(ci_rows), pd.DataFrame(diff_rows)


def q_decomp(trades: pd.DataFrame, split: str = "OOS") -> pd.DataFrame:
    d = trades[trades["split"].eq(split)].copy()
    piv = d.pivot_table(index=["trade_row_id", "candidate_id", "quadrant"], columns="strategy", values="net_pct", aggfunc="first").reset_index()
    rows = []
    for strategy in [c for c in piv.columns if c not in ["trade_row_id", "candidate_id", "quadrant", "S2_no_take_profit", "S3_tp2_exit"]]:
        for qname, g in piv.groupby("quadrant"):
            if qname not in ["Q1_tp2_hit_notp_win", "Q2_tp2_hit_notp_loss_rescue"]:
                continue
            s2 = g["S2_no_take_profit"]
            s3 = g["S3_tp2_exit"]
            var = g[strategy]
            if qname.startswith("Q1"):
                gap = (s2 - s3).sum()
                rec = (var - s3).sum()
                ratio = rec / gap * 100.0 if abs(gap) > 1e-12 else np.nan
                rows.append({"split": split, "strategy": strategy, "quadrant": qname, "n": int(len(g)), "s2_sum_net": float(s2.sum()), "s3_sum_net": float(s3.sum()), "variant_sum_net": float(var.sum()), "q1_recaptured_vs_s3_pct_points": float(rec), "q1_recapture_ratio_pct_of_s2_gap": float(ratio), "q2_rescue_retention_pct": np.nan})
            else:
                rescue = (s3 - s2).sum()
                keep = (var - s2).sum()
                ratio = keep / rescue * 100.0 if abs(rescue) > 1e-12 else np.nan
                rows.append({"split": split, "strategy": strategy, "quadrant": qname, "n": int(len(g)), "s2_sum_net": float(s2.sum()), "s3_sum_net": float(s3.sum()), "variant_sum_net": float(var.sum()), "q1_recaptured_vs_s3_pct_points": np.nan, "q1_recapture_ratio_pct_of_s2_gap": np.nan, "q2_rescue_retention_pct": float(ratio)})
    return pd.DataFrame(rows)


def load_close_data(tickers: list[str]) -> tuple[dict[str, pd.Series], pd.DatetimeIndex]:
    out = {}
    dates = set()
    for t in tickers:
        df = load_ohlc(t)
        s = pd.Series(pd.to_numeric(df["Close"], errors="coerce").to_numpy(), index=df["Date"])
        s = s.dropna().sort_index()
        out[t] = s
        dates.update(s.index.tolist())
    return out, pd.DatetimeIndex(sorted(dates))


def close_on_or_before(close_by_ticker: dict[str, pd.Series], ticker: str, d: pd.Timestamp, fallback: float) -> float:
    s = close_by_ticker.get(ticker)
    if s is None or s.empty:
        return fallback
    try:
        v = s.asof(pd.Timestamp(d))
        if pd.notna(v) and float(v) > 0:
            return float(v)
    except Exception:
        pass
    return fallback


def perf_metrics(curve: pd.DataFrame, accepted: int, skipped: int, total_signals: int, k: int, strategy: str) -> dict[str, Any]:
    eq = pd.to_numeric(curve["equity"], errors="coerce").ffill().fillna(1.0)
    ret = eq.pct_change().fillna(0.0)
    final = float(eq.iloc[-1]) if len(eq) else 1.0
    days = max(1, (pd.Timestamp(curve["date"].iloc[-1]) - pd.Timestamp(curve["date"].iloc[0])).days) if len(curve) else 1
    cagr = (final ** (365.0 / days) - 1.0) * 100.0 if final > 0 else -100.0
    dd = eq / eq.cummax() - 1.0
    mdd = float(dd.min() * 100.0) if len(dd) else 0.0
    std = float(ret.std(ddof=1))
    sharpe = float(ret.mean() / std * math.sqrt(TRADING_DAYS_PER_YEAR)) if std > 0 else 0.0
    active = pd.to_numeric(curve["active_count"], errors="coerce")
    return {"strategy": strategy, "K": int(k), "total_signals": int(total_signals), "realized_trades": int(accepted), "skipped_signals": int(skipped), "skip_rate_pct": float(skipped / total_signals * 100.0) if total_signals else 0.0, "final_multiplier": final, "total_return_pct": (final - 1.0) * 100.0, "CAGR_pct": cagr, "MDD_pct": mdd, "Sharpe_daily_ann": sharpe, "avg_active_positions": float(active.mean()), "max_active_positions": int(active.max()), "avg_slot_occupancy_pct": float(active.mean() / k * 100.0)}


def simulate_slots(strategy_trades: pd.DataFrame, close_by_ticker: dict[str, pd.Series], calendar: pd.DatetimeIndex, k: int, strategy: str, priority: dict[str, float]) -> tuple[pd.DataFrame, dict[str, Any]]:
    trades = strategy_trades.copy()
    trades["candidate_priority"] = trades["candidate_id"].map(priority).fillna(0.0)
    trades["entry_signal_score"] = pd.to_numeric(trades.get("entry_signal_score"), errors="coerce").fillna(0.0)
    trades = trades.sort_values(["entry_date", "candidate_priority", "entry_signal_score", "candidate_id", "trade_row_id"], ascending=[True, False, False, True, True])
    entries = {d: g.copy() for d, g in trades.groupby("entry_date")}
    slots = [{"equity": 1.0 / k, "active": None} for _ in range(k)]
    skipped = 0
    accepted = 0
    rows = []
    for d in calendar:
        day_entries = entries.get(d)
        acc_today = 0
        skip_today = 0
        if day_entries is not None and len(day_entries):
            free = [i for i, s in enumerate(slots) if s["active"] is None]
            for _, r in day_entries.iterrows():
                if free:
                    idx = free.pop(0)
                    slots[idx]["active"] = {"ticker": r["ticker"], "entry_price": float(r["entry_price"]), "exit_date": pd.Timestamp(r["exit_date"]), "exit_price": float(r["exit_price"]), "net_pct": float(r["net_pct"]), "entry_slot_equity": float(slots[idx]["equity"])}
                    accepted += 1
                    acc_today += 1
                else:
                    skipped += 1
                    skip_today += 1
        active_count = sum(1 for s in slots if s["active"] is not None)
        total = 0.0
        for s in slots:
            a = s["active"]
            if a is None:
                total += float(s["equity"])
                continue
            if pd.Timestamp(a["exit_date"]) <= d:
                val = float(a["entry_slot_equity"]) * (1.0 + float(a["net_pct"]) / 100.0)
                s["equity"] = val
                s["active"] = None
                total += val
            else:
                close = close_on_or_before(close_by_ticker, str(a["ticker"]), d, float(a["entry_price"]))
                total += float(a["entry_slot_equity"]) * (close / float(a["entry_price"]))
        rows.append({"date": date_str(d), "strategy": strategy, "K": int(k), "equity": total, "active_count": active_count, "accepted_today": acc_today, "skipped_today": skip_today})
    curve = pd.DataFrame(rows)
    curve["daily_return"] = curve["equity"].pct_change().fillna(0.0)
    return curve, perf_metrics(curve, accepted, skipped, len(trades), k, strategy)


def prepare_portfolio_trades(trades: pd.DataFrame, strategy: str) -> pd.DataFrame:
    d = trades[(trades["split"].eq("OOS")) & (trades["strategy"].eq(strategy))].copy()
    for c in ["entry_date", "exit_date"]:
        d[c] = pd.to_datetime(d[c], errors="coerce")
    d = d.dropna(subset=["entry_date", "exit_date", "entry_price", "exit_price", "net_pct"])
    d = d[(d["entry_date"] >= OOS_START) & (d["entry_date"] <= OOS_END)]
    d = d[d["exit_date"] >= d["entry_date"]]
    return d


def portfolio_layer(trades: pd.DataFrame, priority: dict[str, float]) -> tuple[pd.DataFrame, pd.DataFrame]:
    tickers = sorted(trades[trades["split"].eq("OOS")]["ticker"].astype(str).str.upper().unique())
    close_by_ticker, all_dates = load_close_data(tickers)
    max_exit = pd.to_datetime(trades[trades["split"].eq("OOS")]["exit_date"], errors="coerce").max()
    sim_end = max(pd.Timestamp(max_exit), OOS_END)
    calendar = all_dates[(all_dates >= OOS_START) & (all_dates <= sim_end)]
    curves = []
    perfs = []
    for s in sorted(trades["strategy"].unique()):
        st = prepare_portfolio_trades(trades, s)
        for k in PORT_K:
            curve, perf = simulate_slots(st, close_by_ticker, calendar, k, s, priority)
            curves.append(curve)
            perfs.append(perf)
            print(f"[PORT] {s} K={k} CAGR={perf['CAGR_pct']:.2f} MDD={perf['MDD_pct']:.2f} skip={perf['skip_rate_pct']:.2f}", flush=True)
    return pd.concat(curves, ignore_index=True), pd.DataFrame(perfs)


def final_verdict(trade_metrics: pd.DataFrame, diff_oos: pd.DataFrame, port: pd.DataFrame, is_metrics: pd.DataFrame) -> tuple[str, dict[str, Any]]:
    s2_port = port[port["strategy"].eq("S2_no_take_profit")].set_index("K")
    candidates = []
    for s in sorted(port["strategy"].unique()):
        if s == "S2_no_take_profit":
            continue
        g = port[port["strategy"].eq(s)].set_index("K")
        better_cagr = bool(all(g.loc[k, "CAGR_pct"] > s2_port.loc[k, "CAGR_pct"] for k in PORT_K)) if all(k in g.index for k in PORT_K) else False
        better_sharpe = bool(all(g.loc[k, "Sharpe_daily_ann"] > s2_port.loc[k, "Sharpe_daily_ann"] for k in PORT_K)) if all(k in g.index for k in PORT_K) else False
        better_mdd = bool(all(g.loc[k, "MDD_pct"] > s2_port.loc[k, "MDD_pct"] for k in PORT_K)) if all(k in g.index for k in PORT_K) else False
        ci = diff_oos[diff_oos["strategy"].eq(s)]
        ci_net_clear = bool(len(ci) and float(ci["diff_net_ci_low"].iloc[0]) > 0)
        ci_day_clear = bool(len(ci) and float(ci["diff_perday_ci_low"].iloc[0]) > 0)
        is_row = is_metrics[is_metrics["strategy"].eq(s)]
        is_s2 = is_metrics[is_metrics["strategy"].eq("S2_no_take_profit")]
        is_net_better = bool(len(is_row) and len(is_s2) and float(is_row["avg_net_pct"].iloc[0]) > float(is_s2["avg_net_pct"].iloc[0]))
        is_day_better = bool(len(is_row) and len(is_s2) and float(is_row["mean_net_per_day_pct"].iloc[0]) > float(is_s2["mean_net_per_day_pct"].iloc[0]))
        candidates.append({"strategy": s, "better_cagr_all_K": better_cagr, "better_sharpe_all_K": better_sharpe, "better_mdd_all_K": better_mdd, "oos_ci_net_clear": ci_net_clear, "oos_ci_perday_clear": ci_day_clear, "is_net_better": is_net_better, "is_perday_better": is_day_better})
    cand = pd.DataFrame(candidates)
    # Strict win requires portfolio CAGR or Sharpe all K + CI + IS consistency.
    strict = cand[((cand["better_cagr_all_K"] | cand["better_sharpe_all_K"]) & (cand["oos_ci_net_clear"] | cand["oos_ci_perday_clear"]) & (cand["is_net_better"] | cand["is_perday_better"]))]
    if len(strict):
        verdict = "VARIANT_BEATS_S2"
    else:
        any_trade_or_risk = bool(((cand["better_mdd_all_K"] | cand["better_sharpe_all_K"] | cand["oos_ci_perday_clear"]) & ~(cand["better_cagr_all_K"] & cand["oos_ci_net_clear"])).any())
        verdict = "MIXED" if any_trade_or_risk else "S2_STILL_BEST"
    return verdict, {"variant_s2_comparison_flags": cand.to_dict(orient="records")}


def main() -> int:
    started = time.time()
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    PERSIST_DIR.mkdir(parents=True, exist_ok=True)
    base = pd.read_csv(TRADE_PATH)
    if "trade_row_id" not in base.columns:
        base = base.reset_index(drop=False).rename(columns={"index": "trade_row_id"})
    print(f"base rows={len(base)} IS={(base['split'].astype(str).str.upper()=='IS').sum()} OOS={(base['split'].astype(str).str.upper()=='OOS').sum()}", flush=True)
    trade_variants = build_variant_table(base)
    trade_variants.to_csv(OUT_DIR / "trade_level_variants.csv", index=False, float_format="%.12g", lineterminator="\n")
    is_metrics = metric_table(trade_variants, "IS")
    oos_metrics = metric_table(trade_variants, "OOS")
    trade_metrics = pd.concat([is_metrics, oos_metrics], ignore_index=True)
    trade_metrics.to_csv(OUT_DIR / "trade_variant_metrics.csv", index=False, float_format="%.12g", lineterminator="\n")
    ci_is, diff_is = bootstrap_tables(trade_variants, "IS")
    ci_oos, diff_oos = bootstrap_tables(trade_variants, "OOS")
    ci = pd.concat([ci_is, ci_oos], ignore_index=True)
    diff = pd.concat([diff_is, diff_oos], ignore_index=True)
    ci.to_csv(OUT_DIR / "trade_bootstrap_ci.csv", index=False, float_format="%.12g", lineterminator="\n")
    diff.to_csv(OUT_DIR / "variant_vs_s2_bootstrap_diff.csv", index=False, float_format="%.12g", lineterminator="\n")
    q = q_decomp(trade_variants, "OOS")
    q.to_csv(OUT_DIR / "q1_q2_decomposition.csv", index=False, float_format="%.12g", lineterminator="\n")
    pc = pd.read_csv(CAND_PATH)
    pc["priority"] = pc[["is_S1_mean_perday", "is_S2_mean_perday", "is_S3_mean_perday"]].max(axis=1)
    priority = pc.set_index("candidate_id")["priority"].to_dict()
    curves, port = portfolio_layer(trade_variants, priority)
    curves.to_csv(OUT_DIR / "equity_curves_variants.csv", index=False, float_format="%.12g", lineterminator="\n")
    port.to_csv(OUT_DIR / "portfolio_variants.csv", index=False, float_format="%.12g", lineterminator="\n")
    verdict, verdict_detail = final_verdict(trade_metrics, diff_oos, port, is_metrics)

    # winners
    winners = []
    for k, g in port.groupby("K"):
        idx_cagr = g["CAGR_pct"].idxmax()
        idx_sharpe = g["Sharpe_daily_ann"].idxmax()
        idx_mdd = g["MDD_pct"].idxmax()
        winners.append({"K": int(k), "winner_CAGR": g.loc[idx_cagr, "strategy"], "winner_CAGR_pct": float(g.loc[idx_cagr, "CAGR_pct"]), "winner_CAGR_MDD_pct": float(g.loc[idx_cagr, "MDD_pct"]), "winner_Sharpe": g.loc[idx_sharpe, "strategy"], "winner_Sharpe_value": float(g.loc[idx_sharpe, "Sharpe_daily_ann"]), "best_MDD_strategy": g.loc[idx_mdd, "strategy"], "best_MDD_pct": float(g.loc[idx_mdd, "MDD_pct"])})
    winners_df = pd.DataFrame(winners)
    winners_df.to_csv(OUT_DIR / "portfolio_winners_by_k.csv", index=False, float_format="%.12g", lineterminator="\n")

    summary = {"created_at": datetime.now().isoformat(timespec="seconds"), "seed": SEED, "n_boot": N_BOOT, "verdict": verdict, "input": str(TRADE_PATH), "ohlc_snapshot_dir": str(SNAP_DIR), "out_dir": str(OUT_DIR), "persist_dir": str(PERSIST_DIR), "rows": {"base": int(len(base)), "trade_variants": int(len(trade_variants)), "IS_base": int((base['split'].astype(str).str.upper()=='IS').sum()), "OOS_base": int((base['split'].astype(str).str.upper()=='OOS').sum())}, "fixed_parameters": {"trail_pct_candidates_fixed": TRAIL_PCTS, "target_pct": 3.0, "tp2_trigger_pct": 2.0, "momentum_close_position_threshold": 0.5, "momentum_volume_ratio_threshold": 1.0, "portfolio_K": PORT_K, "commission_rate": COMMISSION_RATE}, "daily_bar_assumptions": {"same_date_collision": "If variant event date is the same as S2 fallback exit date, S2 fallback is used to preserve original daily-bar conflict ordering.", "trail_floor_activation": "Protective trail/floor checks start from the trading day after the +2% hit day to avoid intraday ordering ambiguity; +3% target can trigger on the +2% hit day."}, "winners_by_k": winners_df.to_dict(orient="records"), "verdict_detail": verdict_detail, "elapsed_sec": round(time.time() - started, 3)}
    (OUT_DIR / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2, default=str), encoding="utf-8")

    readout = []
    readout.append("# Exit variants full comparison — frozen data")
    readout.append("")
    readout.append(f"- verdict: **{verdict}**")
    readout.append(f"- seed: {SEED}")
    readout.append(f"- input: `{TRADE_PATH}`")
    readout.append(f"- OHLC: `{SNAP_DIR}`")
    readout.append("- Parameter search/grid search: prohibited; all compared variants are fixed a priori.")
    readout.append("- Same-date variant/S2 collision falls back to S2; trail/floor protective checks start from next bar after +2 hit; target +3 may trigger on hit day.")
    readout.append("")
    readout.append("## OOS trade-level metrics")
    readout.append(oos_metrics.to_markdown(index=False))
    readout.append("")
    readout.append("## IS trade-level metrics")
    readout.append(is_metrics.to_markdown(index=False))
    readout.append("")
    readout.append("## OOS variant vs S2 bootstrap diff")
    readout.append(diff_oos.to_markdown(index=False))
    readout.append("")
    readout.append("## Q1/Q2 recapture/rescue decomposition")
    readout.append(q.to_markdown(index=False))
    readout.append("")
    readout.append("## Portfolio variants, OOS, K=20/10")
    show_cols = ["strategy", "K", "realized_trades", "skipped_signals", "skip_rate_pct", "final_multiplier", "CAGR_pct", "MDD_pct", "Sharpe_daily_ann", "avg_slot_occupancy_pct"]
    readout.append(port[show_cols].to_markdown(index=False))
    readout.append("")
    readout.append("## Winners by K")
    readout.append(winners_df.to_markdown(index=False))
    readout.append("")
    readout.append("## Files")
    for fn in ["readout.md", "trade_level_variants.csv", "trade_variant_metrics.csv", "trade_bootstrap_ci.csv", "variant_vs_s2_bootstrap_diff.csv", "q1_q2_decomposition.csv", "portfolio_variants.csv", "equity_curves_variants.csv", "portfolio_winners_by_k.csv", "summary.json"]:
        readout.append(f"- `{OUT_DIR / fn}`")
        readout.append(f"- `{PERSIST_DIR / fn}`")
    (OUT_DIR / "readout.md").write_text("\n".join(readout) + "\n", encoding="utf-8")

    for p in OUT_DIR.iterdir():
        if p.is_file():
            shutil.copy2(p, PERSIST_DIR / p.name)
    print("DONE", flush=True)
    print("VERDICT", verdict, flush=True)
    print("OUT_DIR", OUT_DIR, flush=True)
    print("PERSIST_DIR", PERSIST_DIR, flush=True)
    print("WINNERS", winners_df.to_dict(orient="records"), flush=True)
    print("ELAPSED_SEC", round(time.time() - started, 3), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
