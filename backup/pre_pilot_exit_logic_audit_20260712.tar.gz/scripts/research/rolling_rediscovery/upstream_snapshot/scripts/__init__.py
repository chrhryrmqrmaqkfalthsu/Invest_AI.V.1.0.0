"""Rolling rediscovery script package."""
