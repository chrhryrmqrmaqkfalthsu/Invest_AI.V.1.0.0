# Exit variants full comparison — frozen data

- verdict: **VARIANT_BEATS_S2**
- seed: 42
- input: `/home/g3000kkw/kingmaker/data/_system/analysis/perday_perstock_20260707/per_trade_strategies.csv`
- OHLC: `/home/g3000kkw/kingmaker/data/_system/analysis/ohlc_snapshot_20260707`
- Parameter search/grid search: prohibited; all compared variants are fixed a priori.
- Same-date variant/S2 collision falls back to S2; trail/floor protective checks start from next bar after +2 hit; target +3 may trigger on hit day.

## OOS trade-level metrics
| split   | strategy          |     n |   sum_net_pct |   avg_net_pct |   median_net_pct |   win_rate_pct |   avg_holding_days |   mean_net_per_day_pct |   median_net_per_day_pct |   avg_MAE_pct |   avg_MFE_pct |
|:--------|:------------------|------:|--------------:|--------------:|-----------------:|---------------:|-------------------:|-----------------------:|-------------------------:|--------------:|--------------:|
| OOS     | S2_no_take_profit | 12915 |       41940.4 |       3.24742 |          2.3096  |        60.3252 |           10.4949  |               0.255661 |                 0.258805 |      -6.45346 |      11.3538  |
| OOS     | S3_tp2_exit       | 12915 |       13134.2 |       1.01697 |          1.697   |        80.4878 |            5.39179 |               0.688014 |                 0.8485   |      -4.50161 |       5.71479 |
| OOS     | S3_trail_1.0      | 12915 |       36868.6 |       2.85471 |          2.84016 |        78.9237 |            5.92265 |               1.19172  |                 0.878932 |      -4.8681  |       6.77204 |
| OOS     | S3_trail_1.5      | 12915 |       33274   |       2.57638 |          2.46524 |        78.916  |            5.93279 |               1.06141  |                 0.734162 |      -4.8683  |       6.78334 |
| OOS     | S3_trail_2.0      | 12915 |       29967.3 |       2.32035 |          2.11503 |        75.0445 |            5.97011 |               0.933327 |                 0.604177 |      -4.87001 |       6.81695 |
| OOS     | S3_target_3pct    | 12915 |       16067.7 |       1.24411 |          2.6955  |        76.6086 |            6.10453 |               0.880934 |                 1.23484  |      -5.03783 |       6.24051 |
| OOS     | S3_target_floor   | 12915 |       16963.4 |       1.31346 |          2.6955  |        69.4696 |            5.59992 |               0.8643   |                 1.1582   |      -4.65148 |       6.04931 |
| OOS     | S3_momentum       | 12915 |       28324.8 |       2.19317 |          1.697   |        75.1684 |            7.06156 |               0.626551 |                 0.8485   |      -4.90392 |       7.75245 |

## IS trade-level metrics
| split   | strategy          |     n |   sum_net_pct |   avg_net_pct |   median_net_pct |   win_rate_pct |   avg_holding_days |   mean_net_per_day_pct |   median_net_per_day_pct |   avg_MAE_pct |   avg_MFE_pct |
|:--------|:------------------|------:|--------------:|--------------:|-----------------:|---------------:|-------------------:|-----------------------:|-------------------------:|--------------:|--------------:|
| IS      | S2_no_take_profit | 31057 |      33314.9  |      1.0727   |         0.786488 |        53.3986 |           10.9935  |             -0.0114893 |                0.0756304 |      -6.47794 |       9.03651 |
| IS      | S3_tp2_exit       | 31057 |       9475.73 |      0.305108 |         1.697    |        74.3246 |            6.19702 |              0.524252  |                0.8485    |      -4.56799 |       4.90525 |
| IS      | S3_trail_1.0      | 31057 |      51554.9  |      1.66001  |         2.22061  |        73.1526 |            6.68706 |              0.838256  |                0.64345   |      -4.90084 |       5.7568  |
| IS      | S3_trail_1.5      | 31057 |      43692.2  |      1.40684  |         1.844    |        73.1494 |            6.70251 |              0.720027  |                0.495888  |      -4.90131 |       5.76756 |
| IS      | S3_trail_2.0      | 31057 |      36603.4  |      1.17859  |         1.49576  |        69.0859 |            6.75648 |              0.604282  |                0.368281  |      -4.90793 |       5.80596 |
| IS      | S3_target_3pct    | 31057 |      14544.1  |      0.468304 |         2.6955   |        70.4092 |            6.97733 |              0.652888  |                0.787586  |      -5.09356 |       5.37017 |
| IS      | S3_target_floor   | 31057 |      16700.2  |      0.537727 |         2.6955   |        63.4672 |            6.42911 |              0.639487  |                0.657336  |      -4.72087 |       5.20973 |
| IS      | S3_momentum       | 31057 |      28554    |      0.919407 |         1.697    |        68.6866 |            7.71945 |              0.417163  |                0.716879  |      -4.94828 |       6.39666 |

## OOS variant vs S2 bootstrap diff
| split   | strategy        |   diff_net_vs_s2 |   diff_net_ci_low |   diff_net_ci_high |   diff_perday_vs_s2 |   diff_perday_ci_low |   diff_perday_ci_high |   clusters |   n_trades |
|:--------|:----------------|-----------------:|------------------:|-------------------:|--------------------:|---------------------:|----------------------:|-----------:|-----------:|
| OOS     | S3_momentum     |        -1.05425  |         -1.39912  |         -0.739672  |            0.37089  |             0.298747 |              0.446209 |         93 |      12915 |
| OOS     | S3_target_3pct  |        -2.00331  |         -2.49994  |         -1.55565   |            0.625273 |             0.534485 |              0.716818 |         93 |      12915 |
| OOS     | S3_target_floor |        -1.93396  |         -2.43407  |         -1.48202   |            0.608638 |             0.513367 |              0.704953 |         93 |      12915 |
| OOS     | S3_tp2_exit     |        -2.23045  |         -2.75411  |         -1.76088   |            0.432352 |             0.328172 |              0.534904 |         93 |      12915 |
| OOS     | S3_trail_1.0    |        -0.392707 |         -0.747079 |         -0.0541327 |            0.936056 |             0.810983 |              1.07064  |         93 |      12915 |
| OOS     | S3_trail_1.5    |        -0.671038 |         -1.02896  |         -0.330185  |            0.805753 |             0.686682 |              0.933812 |         93 |      12915 |
| OOS     | S3_trail_2.0    |        -0.927069 |         -1.29014  |         -0.582084  |            0.677665 |             0.565424 |              0.798868 |         93 |      12915 |

## Q1/Q2 recapture/rescue decomposition
| split   | strategy        | quadrant                    |    n |   s2_sum_net |   s3_sum_net |   variant_sum_net |   q1_recaptured_vs_s3_pct_points |   q1_recapture_ratio_pct_of_s2_gap |   q2_rescue_retention_pct |
|:--------|:----------------|:----------------------------|-----:|-------------:|-------------:|------------------:|---------------------------------:|-----------------------------------:|--------------------------:|
| OOS     | S3_momentum     | Q1_tp2_hit_notp_win         | 5212 |      62076.9 |      8844.76 |          30150.8  |                         21306    |                           40.0248  |                  nan      |
| OOS     | S3_momentum     | Q2_tp2_hit_notp_loss_rescue | 2604 |     -20006.9 |      4418.99 |          -1696.44 |                           nan    |                          nan       |                   74.9634 |
| OOS     | S3_target_3pct  | Q1_tp2_hit_notp_win         | 5212 |      62076.9 |      8844.76 |          15087.2  |                          6242.48 |                           11.7269  |                  nan      |
| OOS     | S3_target_3pct  | Q2_tp2_hit_notp_loss_rescue | 2604 |     -20006.9 |      4418.99 |           1110.01 |                           nan    |                          nan       |                   86.453  |
| OOS     | S3_target_floor | Q1_tp2_hit_notp_win         | 5212 |      62076.9 |      8844.76 |          12730.5  |                          3885.69 |                            7.29951 |                  nan      |
| OOS     | S3_target_floor | Q2_tp2_hit_notp_loss_rescue | 2604 |     -20006.9 |      4418.99 |           4362.46 |                           nan    |                          nan       |                   99.7686 |
| OOS     | S3_trail_1.0    | Q1_tp2_hit_notp_win         | 5212 |      62076.9 |      8844.76 |          29061.7  |                         20217    |                           37.9789  |                  nan      |
| OOS     | S3_trail_1.0    | Q2_tp2_hit_notp_loss_rescue | 2604 |     -20006.9 |      4418.99 |           7936.44 |                           nan    |                          nan       |                  114.4    |
| OOS     | S3_trail_1.5    | Q1_tp2_hit_notp_win         | 5212 |      62076.9 |      8844.76 |          26728.9  |                         17884.2  |                           33.5966  |                  nan      |
| OOS     | S3_trail_1.5    | Q2_tp2_hit_notp_loss_rescue | 2604 |     -20006.9 |      4418.99 |           6674.6  |                           nan    |                          nan       |                  109.235  |
| OOS     | S3_trail_2.0    | Q1_tp2_hit_notp_win         | 5212 |      62076.9 |      8844.76 |          24646.7  |                         15801.9  |                           29.685   |                  nan      |
| OOS     | S3_trail_2.0    | Q2_tp2_hit_notp_loss_rescue | 2604 |     -20006.9 |      4418.99 |           5450.19 |                           nan    |                          nan       |                  104.222  |

## Portfolio variants, OOS, K=20/10
| strategy          |   K |   realized_trades |   skipped_signals |   skip_rate_pct |   final_multiplier |   CAGR_pct |   MDD_pct |   Sharpe_daily_ann |   avg_slot_occupancy_pct |
|:------------------|----:|------------------:|------------------:|----------------:|-------------------:|-----------:|----------:|-------------------:|-------------------------:|
| S2_no_take_profit |  20 |               850 |             12065 |         93.4185 |            2.42936 |    80.2297 |  -21.2911 |            1.63396 |                 100      |
| S2_no_take_profit |  10 |               445 |             12470 |         96.5544 |            2.83938 |    99.8827 |  -25.9809 |            1.55813 |                 100      |
| S3_momentum       |  20 |              1290 |             11625 |         90.0116 |            2.80257 |    98.1594 |  -21.592  |            2.04523 |                  99.9202 |
| S3_momentum       |  10 |               673 |             12242 |         94.789  |            2.78851 |    97.4989 |  -27.0117 |            1.7846  |                  99.8936 |
| S3_target_3pct    |  20 |              1335 |             11580 |         89.6632 |            1.73455 |    44.123  |  -25.2302 |            1.25086 |                  99.9069 |
| S3_target_3pct    |  10 |               693 |             12222 |         94.6341 |            2.05703 |    61.3905 |  -29.3129 |            1.43862 |                  99.8936 |
| S3_target_floor   |  20 |              1462 |             11453 |         88.6798 |            2.4144  |    79.4923 |  -15.1521 |            2.04722 |                  99.8936 |
| S3_target_floor   |  10 |               753 |             12162 |         94.1696 |            2.49554 |    83.4733 |  -21.1849 |            1.88555 |                  99.8936 |
| S3_tp2_exit       |  20 |              1530 |             11385 |         88.1533 |            1.66105 |    40.0406 |  -19.8189 |            1.24581 |                  99.9069 |
| S3_tp2_exit       |  10 |               829 |             12086 |         93.5811 |            1.96958 |    56.8041 |  -27.4364 |            1.43131 |                  99.8404 |
| S3_trail_1.0      |  20 |              1408 |             11507 |         89.0979 |            8.70392 |   320.367  |  -10.1404 |            4.07564 |                  99.9069 |
| S3_trail_1.0      |  10 |               740 |             12175 |         94.2702 |            8.75844 |   322.113  |  -14.7139 |            3.91732 |                  99.9468 |
| S3_trail_1.5      |  20 |              1406 |             11509 |         89.1134 |            7.18172 |   270.019  |  -12.6991 |            3.5429  |                  99.9069 |
| S3_trail_1.5      |  10 |               739 |             12176 |         94.278  |            7.55881 |   282.802  |  -17.7476 |            3.63301 |                  99.9468 |
| S3_trail_2.0      |  20 |              1405 |             11510 |         89.1212 |            5.72359 |   218.285  |  -15.1975 |            3.21181 |                  99.9069 |
| S3_trail_2.0      |  10 |               727 |             12188 |         94.3709 |            5.52347 |   210.856  |  -17.6537 |            3.09868 |                  99.9468 |

## Winners by K
|   K | winner_CAGR   |   winner_CAGR_pct |   winner_CAGR_MDD_pct | winner_Sharpe   |   winner_Sharpe_value | best_MDD_strategy   |   best_MDD_pct |
|----:|:--------------|------------------:|----------------------:|:----------------|----------------------:|:--------------------|---------------:|
|  10 | S3_trail_1.0  |           322.113 |              -14.7139 | S3_trail_1.0    |               3.91732 | S3_trail_1.0        |       -14.7139 |
|  20 | S3_trail_1.0  |           320.367 |              -10.1404 | S3_trail_1.0    |               4.07564 | S3_trail_1.0        |       -10.1404 |

## Files
- `/tmp/exit_variants_20260707_1747/readout.md`
- `/home/g3000kkw/kingmaker/data/_system/analysis/exit_variants_20260707/readout.md`
- `/tmp/exit_variants_20260707_1747/trade_level_variants.csv`
- `/home/g3000kkw/kingmaker/data/_system/analysis/exit_variants_20260707/trade_level_variants.csv`
- `/tmp/exit_variants_20260707_1747/trade_variant_metrics.csv`
- `/home/g3000kkw/kingmaker/data/_system/analysis/exit_variants_20260707/trade_variant_metrics.csv`
- `/tmp/exit_variants_20260707_1747/trade_bootstrap_ci.csv`
- `/home/g3000kkw/kingmaker/data/_system/analysis/exit_variants_20260707/trade_bootstrap_ci.csv`
- `/tmp/exit_variants_20260707_1747/variant_vs_s2_bootstrap_diff.csv`
- `/home/g3000kkw/kingmaker/data/_system/analysis/exit_variants_20260707/variant_vs_s2_bootstrap_diff.csv`
- `/tmp/exit_variants_20260707_1747/q1_q2_decomposition.csv`
- `/home/g3000kkw/kingmaker/data/_system/analysis/exit_variants_20260707/q1_q2_decomposition.csv`
- `/tmp/exit_variants_20260707_1747/portfolio_variants.csv`
- `/home/g3000kkw/kingmaker/data/_system/analysis/exit_variants_20260707/portfolio_variants.csv`
- `/tmp/exit_variants_20260707_1747/equity_curves_variants.csv`
- `/home/g3000kkw/kingmaker/data/_system/analysis/exit_variants_20260707/equity_curves_variants.csv`
- `/tmp/exit_variants_20260707_1747/portfolio_winners_by_k.csv`
- `/home/g3000kkw/kingmaker/data/_system/analysis/exit_variants_20260707/portfolio_winners_by_k.csv`
- `/tmp/exit_variants_20260707_1747/summary.json`
- `/home/g3000kkw/kingmaker/data/_system/analysis/exit_variants_20260707/summary.json`
