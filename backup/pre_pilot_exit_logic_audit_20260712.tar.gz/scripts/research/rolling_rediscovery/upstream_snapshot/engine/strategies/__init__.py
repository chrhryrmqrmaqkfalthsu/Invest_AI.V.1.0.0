"""Rolling rediscovery strategies package."""
