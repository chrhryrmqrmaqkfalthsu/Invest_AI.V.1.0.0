# Drift cause report

## yfinance 호출 옵션 원문
- 파일: `engine/core/data_loader.py`
- L94: `df = yf.download(yf_ticker, start=start, end=end, progress=False, auto_adjust=False)`
- L189: `hist = t.history(period="2d")`

## 옵션 해석
- `auto_adjust=False`가 엔진 OHLC 다운로드에 명시되어 있다.
- `back_adjust`, `repair`, `actions`는 엔진 다운로드에서 명시되지 않아 yfinance 기본값에 의존한다.
- 현재가 보조 경로 `Ticker.history(period='2d')`도 별도 조정 옵션을 명시하지 않는다.

## 표본 OHLC/기업행동 진단
- sample_rows: 20
- entry_day_missing: 0
- non_unit_adj_close_ratio_rows: 8
- dividend_event_rows_in_window: 9
- split_event_rows_in_window: 1

## 스냅샷 커버리지
- tickers_total: 91
- tickers_ok: 91
- coverage_shortfall_tickers: 0
- min_start_date: 2020-06-08
- max_end_date: 2026-07-06

## 원인 판정
이전 1차 산출물의 OHLC 파일이 유실되어 거래별 candle diff를 직접 계산할 수는 없다. 다만 후보 수는 93개, unique ticker는 91개로 복원됐고, self-consistency는 100%였으며 signal/context error는 없었다. 따라서 drift는 룰북 난수나 신호 비결정성보다는 고정되지 않은 외부 OHLC 이력에 의해 발생한 것으로 보는 것이 타당하다.

세부 분류는 다음과 같다.
- (a) 수정/보정 이력 소급 변경: 가능성이 가장 큼. 엔진은 `auto_adjust=False`라 배당 조정 OHLC를 직접 쓰지는 않지만, Yahoo/yfinance의 원천 히스토리는 split 반영 및 과거 데이터 정정에 따라 과거 봉이 바뀔 수 있다. 표본에서도 Adj Close와 Close의 비율 및 배당 이벤트가 확인되어 corporate-action 메타데이터가 가격 계열에 영향을 줄 수 있는 상태다.
- (b) 최근 봉 추가/누락: 보조 가능성. OOS entry는 2026-07-02까지지만, 그 직전 진입분의 청산은 이후 봉 가용성에 영향을 받는다.
- (c) 종목별 히스토리 길이 변화: 이번 현재 스냅샷 기준으로는 큰 결손 원인으로 보이지 않는다. manifest상 커버리지 미달 종목이 없다면 row-count drift의 주원인은 아니다.

결론: +2.07%와 +3.10%는 서로 다른 yfinance/재현 시점 산물이며 어느 쪽도 절대 진실이 아니다. 이후 정본은 이번 `ohlc_snapshot` CSV와 그로부터 만든 `oos_trades_frozen.csv`다. 절대 수치보다 같은 frozen 기준 안에서의 방향성과 상대 비교를 신뢰 대상으로 삼는다.
