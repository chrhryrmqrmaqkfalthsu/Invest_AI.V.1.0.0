"""Rolling rediscovery research package."""
