from __future__ import annotations

import hashlib
import json
import math
import os
import re
import shutil
import time
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

SEED = 42
N_BOOT = 10000
MIN_IS_N = 30
COMMISSION_RATE = 0.003
TP2_GROSS_PCT = 2.0
np.random.seed(SEED)

ROOT = Path.cwd()
OUT_DIR = Path(os.environ["PERDAY_OUT_DIR"]).resolve()
PERSIST_DIR = (ROOT / os.environ["PERDAY_PERSIST_DIR"]).resolve()
FROZEN_TRADES = ROOT / "data/_system/analysis/oos_reproduce_frozen_20260707/oos_trades_frozen.csv"
SNAP_DIR = ROOT / "data/_system/analysis/ohlc_snapshot_20260707"

IS_START = pd.Timestamp("2021-01-01")
IS_END = pd.Timestamp("2024-12-31")
OOS_START = pd.Timestamp("2025-01-01")
OOS_END = pd.Timestamp("2026-07-02")

from engine.live.elite_shadow_report import build_elite_shadow_report
from engine.live.elite_shadow_trader import _load_rulebook_for_candidate
from engine.pipeline.context import prepare_ticker_context
from engine.learning.backtest import _lookup_signal_context, _precompute_topic_feature_map, _news_zscore_window
from engine.strategies.rulebook import Rulebook
from engine.core.exit_policy import (
    ExitExecutionConfig,
    MarketContext,
    PriceSnapshot,
    evaluate_exit,
    initialize_position_state,
)


def safe_name(ticker: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", str(ticker).upper())


def safe_float(x: Any, default: float = np.nan) -> float:
    try:
        if x is None or x == "":
            return default
        y = float(x)
        return y if math.isfinite(y) else default
    except Exception:
        return default


def date_str(x: Any) -> str:
    try:
        return pd.Timestamp(x).strftime("%Y-%m-%d")
    except Exception:
        return str(x)[:10]


def normalize_df(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    if "Date" in out.columns:
        out.index = pd.to_datetime(out["Date"], errors="coerce")
        out = out.drop(columns=["Date"])
    else:
        out.index = pd.to_datetime(out.index, errors="coerce")
    try:
        if getattr(out.index, "tz", None) is not None:
            out.index = out.index.tz_localize(None)
    except Exception:
        pass
    out = out[~out.index.isna()].sort_index()
    out = out[~out.index.duplicated(keep="last")]
    return out


def install_frozen_loader() -> None:
    def frozen_load_ohlcv(ticker: str, years: int = 5, end_date: str | None = None, use_cache: bool = True, max_retries: int = 3) -> pd.DataFrame:
        key = str(ticker).upper().strip()
        p = SNAP_DIR / f"{safe_name(key)}_ohlcv.csv"
        if not p.exists():
            raise RuntimeError(f"frozen OHLC snapshot missing for {key}: {p}")
        df = pd.read_csv(p)
        return normalize_df(df)[[c for c in ["Open", "High", "Low", "Close", "Volume"] if c in df.columns]]

    import engine.core.data_loader as data_loader_mod
    import engine.adapters.base as adapter_base_mod

    data_loader_mod.clear_cache()
    data_loader_mod.load_ohlcv = frozen_load_ohlcv
    adapter_base_mod.load_ohlcv = frozen_load_ohlcv


def apply_sell_omen_guard(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    if "sell_omen_score" not in out.columns:
        return out
    dates = pd.to_datetime(out.index, errors="coerce")
    if "sell_omen_model_train_end" in out.columns:
        train_end = pd.to_datetime(out["sell_omen_model_train_end"], errors="coerce")
        valid = train_end.notna() & dates.notna() & (train_end < dates)
    else:
        valid = dates >= pd.Timestamp("2024-01-01")
    out.loc[~valid, "sell_omen_score"] = np.nan
    return out


def compute_net_pct(entry_price: float, exit_price: float) -> float:
    if entry_price <= 0 or exit_price <= 0:
        return np.nan
    gross = (exit_price - entry_price) / entry_price
    commission = (entry_price + exit_price) * (COMMISSION_RATE / 2.0) / entry_price
    return float((gross - commission) * 100.0)


def make_snapshot(df: pd.DataFrame, i: int) -> PriceSnapshot:
    row = df.iloc[i]
    next_row = df.iloc[i + 1] if i + 1 < len(df) else None
    return PriceSnapshot(
        date=date_str(df.index[i]),
        open=safe_float(row.get("Open", row.get("Close"))),
        high=safe_float(row.get("High", row.get("Close"))),
        low=safe_float(row.get("Low", row.get("Close"))),
        close=safe_float(row.get("Close")),
        next_open=safe_float(next_row.get("Open", next_row.get("Close"))) if next_row is not None else None,
    )


def find_idx_by_date(df: pd.DataFrame, value: Any) -> int | None:
    try:
        key = pd.Timestamp(value).strftime("%Y-%m-%d")
        dates = pd.Series(df.index.strftime("%Y-%m-%d"), index=range(len(df)))
        hit = dates[dates == key]
        if len(hit):
            return int(hit.index[0])
    except Exception:
        return None
    return None


def load_candidates() -> dict[str, dict[str, Any]]:
    report = build_elite_shadow_report(stage2_limit=60, stage3_limit=80, include_trades=False)
    out = {}
    for c in list(report.get("candidates") or [])[:93]:
        out[str(c.get("candidate_id"))] = c
    return out


def load_rulebooks(candidates: dict[str, dict[str, Any]]) -> dict[str, Rulebook]:
    rulebooks: dict[str, Rulebook] = {}
    for cid, cand in candidates.items():
        rb_dict = _load_rulebook_for_candidate(cand)
        if not isinstance(rb_dict, dict) or not rb_dict:
            raise RuntimeError(f"rulebook_missing:{cid}")
        rb_dict = dict(rb_dict)
        rb_dict["ticker"] = str(cand.get("ticker") or "").upper()
        rulebooks[cid] = Rulebook.from_dict(rb_dict)
    return rulebooks


def load_contexts(tickers: list[str]) -> dict[str, dict[str, Any]]:
    contexts = {}
    for i, ticker in enumerate(tickers, 1):
        ctx = prepare_ticker_context(ticker)
        df = normalize_df(ctx["df"])
        df = apply_sell_omen_guard(df)
        ctx["df"] = df
        contexts[ticker] = ctx
        print(f"[CTX {i:03d}/{len(tickers):03d}] {ticker} rows={len(df)} {date_str(df.index.min())}~{date_str(df.index.max())}", flush=True)
    return contexts


def signal_market_context(row: pd.Series, rb: Rulebook, ctx: dict[str, Any]) -> tuple[float, float, float]:
    df = ctx["df"]
    sig_idx = find_idx_by_date(df, row.get("signal_date"))
    entry_idx = find_idx_by_date(df, row.get("entry_date"))
    if sig_idx is None and entry_idx is not None:
        sig_idx = max(0, entry_idx - 1)
    if sig_idx is None:
        return 50.0, 50.0, 18.0
    try:
        topic_window = _news_zscore_window(rb)
        ticker_sentiment = ctx.get("ticker_sentiment") or {}
        topic_feature_map = _precompute_topic_feature_map(ticker_sentiment, topic_window)
        sector_name = str(getattr(rb, "sector_name", "") or ctx.get("sector_name") or "tech")
        cm, cs, cv, _snt, _ef, _topic = _lookup_signal_context(
            df=df,
            idx=sig_idx,
            market_score=50.0,
            sector_score=50.0,
            vix_level=18.0,
            market_history_df=ctx.get("market_history_df"),
            sector_name=sector_name,
            ticker_sentiment=ticker_sentiment,
            topic_feature_map=topic_feature_map,
            use_llm_events=False,
        )
        return float(cm), float(cs), float(cv)
    except Exception:
        return 50.0, 50.0, 18.0


def simulate_s2_notp(row: pd.Series, rb: Rulebook, ctx: dict[str, Any]) -> dict[str, Any]:
    ticker = str(row.get("ticker") or "").upper()
    df = ctx["df"]
    entry_idx = find_idx_by_date(df, row.get("entry_date"))
    if entry_idx is None:
        return {"error": "entry_date_missing"}
    if entry_idx + 1 >= len(df):
        return {"error": "no_future_bar"}
    entry_price = safe_float(row.get("entry_price"))
    if not math.isfinite(entry_price) or entry_price <= 0:
        return {"error": "bad_entry_price"}
    entry_row = df.iloc[entry_idx]
    atr = safe_float(entry_row.get("ATR"), entry_price * 0.02)
    if not math.isfinite(atr) or atr <= 0:
        atr = entry_price * 0.02
    market_score, sector_score, vix_level = signal_market_context(row, rb, ctx)
    mctx = MarketContext(market_score=market_score, vix_level=vix_level, sector_score=sector_score)
    position = initialize_position_state(
        ticker=ticker,
        entry_price=float(entry_price),
        shares=1.0,
        rulebook=rb,
        atr_value=float(atr),
        market_context=mctx,
        entry_date=date_str(row.get("entry_date")),
    )
    breakeven_enabled = bool(getattr(rb, "breakeven_enabled", None)) if getattr(rb, "breakeven_enabled", None) is not None else float(getattr(rb, "breakeven_trigger_profit_pct", 0.0) or 0.0) > 0.0
    sell_omen_enabled = bool(getattr(rb, "sell_omen_enabled", False))
    sell_omen_threshold = max(0.0, min(1.0, float(getattr(rb, "sell_omen_threshold", 1.0) or 1.0))) if sell_omen_enabled else 1.0
    exec_cfg = ExitExecutionConfig(
        mode="base",
        trailing_activation_bars=2,
        trailing_activation_profit_pct=float(getattr(rb, "trailing_activation_profit_pct", 0.0) or 0.0),
        breakeven_enabled=breakeven_enabled,
        breakeven_trigger_profit_pct=float(getattr(rb, "breakeven_trigger_profit_pct", 0.0) or 0.0) if breakeven_enabled else 0.0,
        breakeven_floor_profit_pct=float(getattr(rb, "breakeven_floor_profit_pct", 0.0) or 0.0) if breakeven_enabled else 0.0,
        sell_omen_enabled=sell_omen_enabled,
        sell_omen_threshold=sell_omen_threshold,
    )
    mfe = 0.0
    mae = 0.0
    max_hold = int(row.get("max_holding_days") if pd.notna(row.get("max_holding_days")) else getattr(rb, "max_holding_days", 20) or 20)
    max_hold = max(1, max_hold)
    last_idx = min(entry_idx + max_hold, len(df) - 1)
    for i in range(entry_idx + 1, last_idx + 1):
        snap = make_snapshot(df, i)
        if position.avg_cost > 0:
            if snap.high is not None and math.isfinite(float(snap.high)):
                mfe = max(mfe, (float(snap.high) - position.avg_cost) / position.avg_cost * 100.0)
            if snap.low is not None and math.isfinite(float(snap.low)):
                mae = min(mae, (float(snap.low) - position.avg_cost) / position.avg_cost * 100.0)
        holding = i - entry_idx
        day_ctx = MarketContext(market_score=market_score, vix_level=vix_level, sector_score=sector_score, holding_trading_days=holding, current_trade_date=snap.date)
        score = None
        try:
            if "sell_omen_score" in df.columns:
                raw = safe_float(df.iloc[i].get("sell_omen_score"), np.nan)
                score = max(0.0, min(1.0, raw)) if math.isfinite(raw) else None
        except Exception:
            score = None
        day_cfg = exec_cfg
        if score is not None:
            from dataclasses import replace
            day_cfg = replace(exec_cfg, sell_omen_score=score)
        decision = evaluate_exit(position, snap, rb, day_ctx, day_cfg)
        if decision.updated_position is not None:
            position = decision.updated_position
        if decision.should_exit:
            reason = str(decision.reason)
            if reason == "take_profit":
                continue
            exit_price = decision.fill_price_base if decision.fill_price_base is not None else decision.trigger_price
            if exit_price is None or not math.isfinite(float(exit_price)):
                exit_price = safe_float(df.iloc[i].get("Close"))
            return {
                "net": compute_net_pct(entry_price, float(exit_price)),
                "holding": int(max(1, holding)),
                "exit_date": date_str(df.index[i]),
                "exit_price": float(exit_price),
                "exit_reason": reason,
                "MAE": mae,
                "MFE": mfe,
                "error": "",
            }
    exit_price = safe_float(df.iloc[last_idx].get("Close"))
    return {
        "net": compute_net_pct(entry_price, float(exit_price)),
        "holding": int(max(1, last_idx - entry_idx)),
        "exit_date": date_str(df.index[last_idx]),
        "exit_price": float(exit_price),
        "exit_reason": "time_out",
        "MAE": mae,
        "MFE": mfe,
        "error": "",
    }


def simulate_tp2(row: pd.Series, s2: dict[str, Any], ctx: dict[str, Any]) -> dict[str, Any]:
    df = ctx["df"]
    entry_idx = find_idx_by_date(df, row.get("entry_date"))
    entry_price = safe_float(row.get("entry_price"))
    if entry_idx is None or not math.isfinite(entry_price) or entry_price <= 0:
        out = dict(s2)
        out["tp2_hit_2d"] = False
        out["tp2_hit_date"] = ""
        return out
    target = entry_price * (1.0 + TP2_GROSS_PCT / 100.0)
    for j in [entry_idx, entry_idx + 1]:
        if j >= len(df):
            continue
        high = safe_float(df.iloc[j].get("High", df.iloc[j].get("Close")))
        if math.isfinite(high) and high >= target:
            hold = j - entry_idx + 1
            low_path = pd.to_numeric(df.iloc[entry_idx:j+1].get("Low"), errors="coerce")
            high_path = pd.to_numeric(df.iloc[entry_idx:j+1].get("High"), errors="coerce")
            mae = float(((low_path.min() - entry_price) / entry_price) * 100.0) if len(low_path.dropna()) else 0.0
            mfe = float(((high_path.max() - entry_price) / entry_price) * 100.0) if len(high_path.dropna()) else TP2_GROSS_PCT
            return {
                "net": compute_net_pct(entry_price, target),
                "holding": int(max(1, hold)),
                "exit_date": date_str(df.index[j]),
                "exit_price": float(target),
                "exit_reason": "tp2_2d",
                "MAE": mae,
                "MFE": mfe,
                "error": "",
                "tp2_hit_2d": True,
                "tp2_hit_date": date_str(df.index[j]),
            }
    out = dict(s2)
    out["tp2_hit_2d"] = False
    out["tp2_hit_date"] = ""
    return out


def long_from_wide(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    spec = {
        "S1_original_take_profit_included": ("s1_net", "s1_hold"),
        "S2_no_take_profit_solo": ("s2_net", "s2_hold"),
        "S3_tp2_2d_then_no_take_profit": ("s3_net", "s3_hold"),
    }
    base_cols = ["trade_row_id", "candidate_id", "ticker", "split", "stage", "entry_date"]
    for name, (netc, holdc) in spec.items():
        tmp = df[base_cols].copy()
        tmp["strategy"] = name
        tmp["net_pct"] = pd.to_numeric(df[netc], errors="coerce")
        tmp["holding_days"] = pd.to_numeric(df[holdc], errors="coerce").clip(lower=1)
        tmp["net_per_day_pct"] = tmp["net_pct"] / tmp["holding_days"]
        tmp["win"] = tmp["net_pct"] > 0
        rows.append(tmp)
    return pd.concat(rows, ignore_index=True)


def strategy_summary(long_df: pd.DataFrame, split: str) -> pd.DataFrame:
    d = long_df[long_df["split"].astype(str).eq(split)].copy()
    rows = []
    for strat, g in d.groupby("strategy"):
        rows.append({
            "split": split,
            "strategy": strat,
            "n": int(len(g)),
            "sum_net_pct": float(g["net_pct"].sum()),
            "avg_net_pct": float(g["net_pct"].mean()),
            "mean_net_per_day_pct": float(g["net_per_day_pct"].mean()),
            "median_net_per_day_pct": float(g["net_per_day_pct"].median()),
            "avg_holding_days": float(g["holding_days"].mean()),
            "win_rate_pct": float(g["win"].mean() * 100.0),
        })
    return pd.DataFrame(rows).sort_values("mean_net_per_day_pct", ascending=False)


def cluster_boot_ci(base: pd.DataFrame, value_col: str, n_boot: int = N_BOOT, seed: int = SEED) -> dict[str, Any]:
    tmp = base[["candidate_id", value_col]].dropna().copy()
    clusters = tmp["candidate_id"].astype(str).unique()
    groups = {c: tmp.loc[tmp["candidate_id"].astype(str).eq(c), value_col].to_numpy(dtype=float) for c in clusters}
    rng = np.random.default_rng(seed)
    vals = np.empty(n_boot, dtype=float)
    for i in range(n_boot):
        sampled = rng.choice(clusters, size=len(clusters), replace=True)
        arr = np.concatenate([groups[c] for c in sampled])
        vals[i] = arr.mean()
    lo, mid, hi = np.percentile(vals, [2.5, 50, 97.5])
    return {
        "observed": float(tmp[value_col].mean()),
        "ci95_low": float(lo),
        "ci95_mid": float(mid),
        "ci95_high": float(hi),
        "clusters": int(len(clusters)),
        "n_trades": int(len(tmp)),
        "n_boot": int(n_boot),
        "seed": int(seed),
    }


def exact_binom_p_greater(k: int, n: int, p: float = 1/3) -> float:
    try:
        from scipy.stats import binomtest
        return float(binomtest(k, n, p, alternative="greater").pvalue)
    except Exception:
        if n <= 0:
            return np.nan
        total = 0.0
        for i in range(k, n + 1):
            total += math.comb(n, i) * (p ** i) * ((1 - p) ** (n - i))
        return float(total)


def make_assignment(wide: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, dict[str, Any], str]:
    is_df = wide[wide["split"].astype(str).eq("IS")].copy()
    oos_df = wide[wide["split"].astype(str).eq("OOS")].copy()
    cand_rows = []
    for cid, gis in is_df.groupby("candidate_id"):
        goos = oos_df[oos_df["candidate_id"].eq(cid)]
        row = {"candidate_id": cid, "ticker": str(gis["ticker"].iloc[0]), "is_n": int(len(gis)), "oos_n": int(len(goos))}
        for s, col in [("S1", "s1_perday"), ("S2", "s2_perday"), ("S3", "s3_perday")]:
            row[f"is_{s}_mean_perday"] = float(gis[col].mean())
            row[f"oos_{s}_mean_perday"] = float(goos[col].mean()) if len(goos) else np.nan
        row["eligible_is_n_ge_30"] = bool(row["is_n"] >= MIN_IS_N)
        if row["eligible_is_n_ge_30"]:
            is_vals = {s: row[f"is_{s}_mean_perday"] for s in ["S1", "S2", "S3"]}
            row["is_best_strategy"] = max(is_vals, key=is_vals.get)
        else:
            row["is_best_strategy"] = "WATCH"
        if len(goos):
            oos_vals = {s: row[f"oos_{s}_mean_perday"] for s in ["S1", "S2", "S3"]}
            row["oos_best_strategy"] = max(oos_vals, key=oos_vals.get)
        else:
            row["oos_best_strategy"] = ""
        row["is_oos_best_match"] = bool(row["eligible_is_n_ge_30"] and row["is_best_strategy"] == row["oos_best_strategy"])
        cand_rows.append(row)
    per_candidate = pd.DataFrame(cand_rows).sort_values(["eligible_is_n_ge_30", "is_best_strategy", "candidate_id"], ascending=[False, True, True])
    assign_map = per_candidate.set_index("candidate_id")["is_best_strategy"].to_dict()
    eligible_map = per_candidate.set_index("candidate_id")["eligible_is_n_ge_30"].to_dict()
    assign = oos_df.copy()
    assign["eligible_is_n_ge_30"] = assign["candidate_id"].map(eligible_map).fillna(False).astype(bool)
    assign["assigned_strategy_raw"] = assign["candidate_id"].map(assign_map).fillna("WATCH")
    assign["assigned_strategy"] = assign["assigned_strategy_raw"].replace({"WATCH": "S2"})
    for s, netc, holdc, pdc in [("S1", "s1_net", "s1_hold", "s1_perday"), ("S2", "s2_net", "s2_hold", "s2_perday"), ("S3", "s3_net", "s3_hold", "s3_perday")]:
        mask = assign["assigned_strategy"].eq(s)
        assign.loc[mask, "assigned_net"] = assign.loc[mask, netc]
        assign.loc[mask, "assigned_hold"] = assign.loc[mask, holdc]
        assign.loc[mask, "assigned_perday"] = assign.loc[mask, pdc]

    def summarize_portfolios(use: pd.DataFrame, scope: str) -> pd.DataFrame:
        rows = []
        portfolios = [
            ("uniform_S1_original_tp", "s1_net", "s1_hold", "s1_perday"),
            ("uniform_S2_no_take_profit", "s2_net", "s2_hold", "s2_perday"),
            ("uniform_S3_tp2_then_notp", "s3_net", "s3_hold", "s3_perday"),
            ("IS_best_per_candidate_assignment", "assigned_net", "assigned_hold", "assigned_perday"),
        ]
        for name, netc, holdc, pdc in portfolios:
            rows.append({
                "portfolio": name,
                "scope": scope,
                "n": int(len(use)),
                "sum_net_pct": float(pd.to_numeric(use[netc], errors="coerce").sum()),
                "avg_net_pct": float(pd.to_numeric(use[netc], errors="coerce").mean()),
                "mean_net_per_day_pct": float(pd.to_numeric(use[pdc], errors="coerce").mean()),
                "median_net_per_day_pct": float(pd.to_numeric(use[pdc], errors="coerce").median()),
                "avg_holding_days": float(pd.to_numeric(use[holdc], errors="coerce").clip(lower=1).mean()),
                "win_rate_pct": float((pd.to_numeric(use[netc], errors="coerce") > 0).mean() * 100.0),
            })
        return pd.DataFrame(rows)

    eligible_oos = assign[assign["eligible_is_n_ge_30"]].copy()
    assignment_summary = pd.concat([
        summarize_portfolios(eligible_oos, "eligible_only"),
        summarize_portfolios(assign, "all_watch_s2_fallback"),
    ], ignore_index=True)
    eligible_cands = per_candidate[per_candidate["eligible_is_n_ge_30"] & per_candidate["oos_best_strategy"].astype(str).ne("")].copy()
    match_n = int(eligible_cands["is_oos_best_match"].sum())
    match_total = int(len(eligible_cands))
    match_rate = float(match_n / match_total * 100.0) if match_total else np.nan
    p_value = exact_binom_p_greater(match_n, match_total, 1/3) if match_total else np.nan
    elig_sum = assignment_summary[assignment_summary["scope"].eq("eligible_only")].set_index("portfolio")
    uniform_means = {
        "S1": float(elig_sum.loc["uniform_S1_original_tp", "mean_net_per_day_pct"]),
        "S2": float(elig_sum.loc["uniform_S2_no_take_profit", "mean_net_per_day_pct"]),
        "S3": float(elig_sum.loc["uniform_S3_tp2_then_notp", "mean_net_per_day_pct"]),
    }
    uniform_sums = {
        "S1": float(elig_sum.loc["uniform_S1_original_tp", "sum_net_pct"]),
        "S2": float(elig_sum.loc["uniform_S2_no_take_profit", "sum_net_pct"]),
        "S3": float(elig_sum.loc["uniform_S3_tp2_then_notp", "sum_net_pct"]),
    }
    best_uniform = max(uniform_means, key=uniform_means.get)
    assigned_mean = float(elig_sum.loc["IS_best_per_candidate_assignment", "mean_net_per_day_pct"])
    assigned_sum = float(elig_sum.loc["IS_best_per_candidate_assignment", "sum_net_pct"])
    if match_total and p_value < 0.05 and assigned_mean > uniform_means[best_uniform] and assigned_sum > uniform_sums[best_uniform]:
        verdict_b = "PERSTOCK_ASSIGN_HELPS"
    elif not match_total or p_value >= 0.05:
        verdict_b = "PERSTOCK_UNSTABLE"
    else:
        verdict_b = "PERSTOCK_ASSIGN_NO_EDGE"
    stability = {
        "eligible_candidates": int(per_candidate["eligible_is_n_ge_30"].sum()),
        "watch_candidates": int((~per_candidate["eligible_is_n_ge_30"]).sum()),
        "match_n": match_n,
        "match_total": match_total,
        "match_rate_pct": match_rate,
        "random_baseline_pct": 33.33333333333333,
        "p_value_greater_than_random": float(p_value) if not pd.isna(p_value) else None,
        "best_uniform_by_oos_perday": best_uniform,
        "assigned_mean_net_per_day_pct": assigned_mean,
        "assigned_sum_net_pct": assigned_sum,
        "uniform_means_net_per_day_pct": uniform_means,
        "uniform_sums_net_pct": uniform_sums,
    }
    return per_candidate, assign, assignment_summary, stability, verdict_b


def main() -> int:
    started = time.time()
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    PERSIST_DIR.mkdir(parents=True, exist_ok=True)
    install_frozen_loader()
    base = pd.read_csv(FROZEN_TRADES)
    base = base.reset_index(drop=False).rename(columns={"index": "trade_row_id"})
    base["split"] = base["split"].astype(str).str.upper()
    print(f"input rows={len(base)} IS={(base['split']=='IS').sum()} OOS={(base['split']=='OOS').sum()}", flush=True)
    candidates = load_candidates()
    rulebooks = load_rulebooks(candidates)
    tickers = sorted(base["ticker"].astype(str).str.upper().unique())
    contexts = load_contexts(tickers)

    rows = []
    errors = []
    for n, row in base.iterrows():
        cid = str(row["candidate_id"])
        ticker = str(row["ticker"]).upper()
        rb = rulebooks.get(cid)
        ctx = contexts.get(ticker)
        if rb is None or ctx is None:
            errors.append({"trade_row_id": int(row["trade_row_id"]), "candidate_id": cid, "ticker": ticker, "error": "missing_rb_or_context"})
            continue
        s2 = simulate_s2_notp(row, rb, ctx)
        if s2.get("error"):
            errors.append({"trade_row_id": int(row["trade_row_id"]), "candidate_id": cid, "ticker": ticker, "error": s2.get("error")})
        s3 = simulate_tp2(row, s2, ctx)
        out = dict(row)
        out.update({
            "s1_net": safe_float(row.get("net_pct")),
            "s1_hold": int(max(1, safe_float(row.get("holding_days"), 1))),
            "s1_exit_date": row.get("exit_date"),
            "s1_exit_price": safe_float(row.get("exit_price")),
            "s1_exit_reason": row.get("exit_reason"),
            "s2_net": safe_float(s2.get("net")),
            "s2_hold": int(max(1, safe_float(s2.get("holding"), 1))),
            "s2_exit_date": s2.get("exit_date"),
            "s2_exit_price": safe_float(s2.get("exit_price")),
            "s2_exit_reason": s2.get("exit_reason"),
            "s2_MAE": safe_float(s2.get("MAE")),
            "s2_MFE": safe_float(s2.get("MFE")),
            "s3_net": safe_float(s3.get("net")),
            "s3_hold": int(max(1, safe_float(s3.get("holding"), 1))),
            "s3_exit_date": s3.get("exit_date"),
            "s3_exit_price": safe_float(s3.get("exit_price")),
            "s3_exit_reason": s3.get("exit_reason"),
            "s3_MAE": safe_float(s3.get("MAE")),
            "s3_MFE": safe_float(s3.get("MFE")),
            "tp2_hit_2d": bool(s3.get("tp2_hit_2d", False)),
            "tp2_hit_date": s3.get("tp2_hit_date", ""),
            "s2_error": s2.get("error", ""),
        })
        out["s1_perday"] = out["s1_net"] / max(out["s1_hold"], 1)
        out["s2_perday"] = out["s2_net"] / max(out["s2_hold"], 1)
        out["s3_perday"] = out["s3_net"] / max(out["s3_hold"], 1)
        if out["tp2_hit_2d"] and out["s2_net"] > 0:
            out["quadrant"] = "Q1_tp2_hit_notp_win"
        elif out["tp2_hit_2d"] and out["s2_net"] <= 0:
            out["quadrant"] = "Q2_tp2_hit_notp_loss_rescue"
        elif (not out["tp2_hit_2d"]) and out["s2_net"] > 0:
            out["quadrant"] = "Q3_no_tp2_notp_win"
        else:
            out["quadrant"] = "Q4_no_tp2_notp_loss"
        rows.append(out)
        if (n + 1) % 5000 == 0:
            print(f"[REPLAY {n+1}/{len(base)}] errors={len(errors)}", flush=True)
    wide = pd.DataFrame(rows)
    if errors:
        pd.DataFrame(errors).to_csv(OUT_DIR / "replay_errors.csv", index=False)
    else:
        pd.DataFrame(columns=["trade_row_id", "candidate_id", "ticker", "error"]).to_csv(OUT_DIR / "replay_errors.csv", index=False)
    wide.to_csv(OUT_DIR / "per_trade_strategies.csv", index=False, float_format="%.12g", lineterminator="\n")

    long_df = long_from_wide(wide)
    strategy_perday = pd.concat([strategy_summary(long_df, "IS"), strategy_summary(long_df, "OOS")], ignore_index=True)
    oos = wide[wide["split"].eq("OOS")].copy()
    boot_rows = []
    for label, col in [("S1_original_take_profit_included", "s1_perday"), ("S2_no_take_profit_solo", "s2_perday"), ("S3_tp2_2d_then_no_take_profit", "s3_perday")]:
        ci = cluster_boot_ci(oos[["candidate_id", col]].rename(columns={col: "value"}), "value")
        ci["strategy"] = label
        boot_rows.append(ci)
    boot = pd.DataFrame(boot_rows)
    oos["s3_minus_s1_perday"] = oos["s3_perday"] - oos["s1_perday"]
    oos["s3_minus_s2_perday"] = oos["s3_perday"] - oos["s2_perday"]
    diff_s3_s1 = cluster_boot_ci(oos, "s3_minus_s1_perday")
    diff_s3_s2 = cluster_boot_ci(oos, "s3_minus_s2_perday")
    means = strategy_perday[strategy_perday["split"].eq("OOS")].set_index("strategy")["mean_net_per_day_pct"].to_dict()
    s1m = means["S1_original_take_profit_included"]
    s2m = means["S2_no_take_profit_solo"]
    s3m = means["S3_tp2_2d_then_no_take_profit"]
    if s3m < max(s1m, s2m) and diff_s3_s1["ci95_high"] < 0 and diff_s3_s2["ci95_high"] < 0:
        verdict_a = "PERDAY_CONFIRMS_S3_HURTS"
    elif s3m > max(s1m, s2m) and diff_s3_s1["ci95_low"] > 0 and diff_s3_s2["ci95_low"] > 0:
        verdict_a = "PERDAY_REVERSES"
    else:
        verdict_a = "PERDAY_NEUTRAL"

    q = oos.copy()
    q["s3_minus_s2_perday"] = q["s3_perday"] - q["s2_perday"]
    q["s3_minus_s2_net"] = q["s3_net"] - q["s2_net"]
    quadrant = q.groupby("quadrant").agg(
        n=("candidate_id", "size"),
        s1_mean_perday=("s1_perday", "mean"),
        s2_mean_perday=("s2_perday", "mean"),
        s3_mean_perday=("s3_perday", "mean"),
        s3_minus_s2_mean_perday=("s3_minus_s2_perday", "mean"),
        s3_minus_s2_sum_net_pct=("s3_minus_s2_net", "sum"),
        s1_avg_net=("s1_net", "mean"),
        s2_avg_net=("s2_net", "mean"),
        s3_avg_net=("s3_net", "mean"),
        s1_avg_hold=("s1_hold", "mean"),
        s2_avg_hold=("s2_hold", "mean"),
        s3_avg_hold=("s3_hold", "mean"),
    ).reset_index()
    quadrant["pct_oos"] = quadrant["n"] / len(oos) * 100.0

    per_candidate, assignment, assignment_summary, stability, verdict_b = make_assignment(wide)

    strategy_perday.to_csv(OUT_DIR / "strategy_perday.csv", index=False, float_format="%.12g", lineterminator="\n")
    boot.to_csv(OUT_DIR / "strategy_perday_bootstrap_ci.csv", index=False, float_format="%.12g", lineterminator="\n")
    quadrant.to_csv(OUT_DIR / "quadrant_perday_summary.csv", index=False, float_format="%.12g", lineterminator="\n")
    per_candidate.to_csv(OUT_DIR / "per_candidate_best_exit.csv", index=False, float_format="%.12g", lineterminator="\n")
    assignment.to_csv(OUT_DIR / "assignment_oos.csv", index=False, float_format="%.12g", lineterminator="\n")
    assignment_summary.to_csv(OUT_DIR / "assignment_oos_summary.csv", index=False, float_format="%.12g", lineterminator="\n")

    summary = {
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "input_frozen_trades": str(FROZEN_TRADES),
        "ohlc_snapshot_dir": str(SNAP_DIR),
        "out_dir": str(OUT_DIR),
        "persist_dir": str(PERSIST_DIR),
        "seed": SEED,
        "n_boot": N_BOOT,
        "min_is_n": MIN_IS_N,
        "rows": {"all": int(len(wide)), "IS": int((wide["split"] == "IS").sum()), "OOS": int((wide["split"] == "OOS").sum())},
        "tp2_exact_net_pct": compute_net_pct(100.0, 102.0),
        "verdict_a": verdict_a,
        "verdict_b": verdict_b,
        "oos_strategy_mean_net_per_day_pct": means,
        "oos_s3_minus_s1_perday_bootstrap": diff_s3_s1,
        "oos_s3_minus_s2_perday_bootstrap": diff_s3_s2,
        "candidate_assignment_stability": stability,
        "replay_errors": int(len(errors)),
    }
    (OUT_DIR / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2, default=str), encoding="utf-8")

    readout = []
    readout.append("# Frozen per-day / per-stock exit analysis")
    readout.append("")
    readout.append(f"- input: `{FROZEN_TRADES}`")
    readout.append(f"- OHLC snapshot: `{SNAP_DIR}`")
    readout.append(f"- rows: all={len(wide)}, IS={(wide['split']=='IS').sum()}, OOS={(wide['split']=='OOS').sum()}")
    readout.append(f"- TP2 exact net after cost: {compute_net_pct(100.0, 102.0):.6f}%")
    readout.append(f"- replay_errors: {len(errors)}")
    readout.append(f"- verdict A: **{verdict_a}**")
    readout.append(f"- verdict B: **{verdict_b}**")
    readout.append("")
    readout.append("## A. OOS strategy per-day ranking")
    readout.append(strategy_perday[strategy_perday["split"].eq("OOS")].to_markdown(index=False))
    readout.append("")
    readout.append("## A. OOS net/day bootstrap CI")
    readout.append(boot[["strategy", "observed", "ci95_low", "ci95_mid", "ci95_high", "clusters", "n_trades"]].to_markdown(index=False))
    readout.append("")
    readout.append("## A. S3 pairwise per-day diff bootstrap")
    readout.append(pd.DataFrame([
        {"diff": "S3_minus_S1", **diff_s3_s1},
        {"diff": "S3_minus_S2", **diff_s3_s2},
    ])[["diff", "observed", "ci95_low", "ci95_mid", "ci95_high", "clusters", "n_trades"]].to_markdown(index=False))
    readout.append("")
    readout.append("## A. Q1~Q4 OOS per-day decomposition")
    readout.append(quadrant.to_markdown(index=False))
    readout.append("")
    readout.append("## B. OOS assignment comparison")
    readout.append(assignment_summary.to_markdown(index=False))
    readout.append("")
    readout.append("## B. IS/OOS best-exit stability")
    readout.append(f"- eligible candidates: {stability['eligible_candidates']}")
    readout.append(f"- WATCH candidates: {stability['watch_candidates']}")
    readout.append(f"- match: {stability['match_n']}/{stability['match_total']} = {stability['match_rate_pct']:.2f}%")
    readout.append(f"- random baseline: 33.33%")
    readout.append(f"- p-value greater than random: {stability['p_value_greater_than_random']:.6g}")
    readout.append(f"- best uniform by eligible OOS net/day: {stability['best_uniform_by_oos_perday']}")
    readout.append("")
    readout.append("## Files")
    for fn in ["strategy_perday.csv", "strategy_perday_bootstrap_ci.csv", "quadrant_perday_summary.csv", "per_candidate_best_exit.csv", "assignment_oos.csv", "assignment_oos_summary.csv", "per_trade_strategies.csv", "summary.json", "readout.md"]:
        readout.append(f"- `{OUT_DIR / fn}`")
        readout.append(f"- `{PERSIST_DIR / fn}`")
    (OUT_DIR / "readout.md").write_text("\n".join(readout) + "\n", encoding="utf-8")

    # persistent copy
    for p in OUT_DIR.iterdir():
        if p.is_file() and p.name != "run.log":
            shutil.copy2(p, PERSIST_DIR / p.name)
    shutil.copy2(OUT_DIR / "run.log", PERSIST_DIR / "run.log")
    print("DONE", flush=True)
    print("OUT_DIR", OUT_DIR, flush=True)
    print("PERSIST_DIR", PERSIST_DIR, flush=True)
    print("VERDICT_A", verdict_a, flush=True)
    print("VERDICT_B", verdict_b, flush=True)
    print("OOS_MEANS_PERDAY", means, flush=True)
    print("ASSIGNMENT_STABILITY", stability, flush=True)
    print("ELAPSED_SEC", round(time.time() - started, 3), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
