"""Rolling rediscovery learning package."""
