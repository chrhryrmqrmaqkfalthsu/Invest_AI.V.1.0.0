from __future__ import annotations

import json
import math
import os
import re
import shutil
import time
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

SEED = 42
N_BOOT = 10000
TRADING_DAYS_PER_YEAR = 252
ROOT = Path.cwd()
OUT_DIR = Path(os.environ["SCORE_OUT_DIR"]).resolve()
PERSIST_DIR = (ROOT / os.environ["SCORE_PERSIST_DIR"]).resolve()
TRADE_PATH = ROOT / "data/_system/analysis/perday_perstock_20260707/per_trade_strategies.csv"
SNAP_DIR = ROOT / "data/_system/analysis/ohlc_snapshot_20260707"
OOS_START = pd.Timestamp("2025-01-01")
OOS_END = pd.Timestamp("2026-07-02")
K = 20
CUT_KEEP_FRACS = [1.0, 0.8, 0.6, 0.4, 0.2]


def safe_name(ticker: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", str(ticker).upper())


def safe_float(x: Any, default: float = np.nan) -> float:
    try:
        if x is None or x == "":
            return default
        y = float(x)
        return y if math.isfinite(y) else default
    except Exception:
        return default


def date_str(x: Any) -> str:
    try:
        return pd.Timestamp(x).strftime("%Y-%m-%d")
    except Exception:
        return str(x)[:10]


def load_close_data(tickers: list[str]) -> tuple[dict[str, pd.Series], pd.DatetimeIndex]:
    out = {}
    all_dates = set()
    for t in tickers:
        p = SNAP_DIR / f"{safe_name(t)}_ohlcv.csv"
        if not p.exists():
            raise RuntimeError(f"missing snapshot {t}: {p}")
        df = pd.read_csv(p)
        df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
        df = df.dropna(subset=["Date"]).sort_values("Date")
        s = pd.Series(pd.to_numeric(df["Close"], errors="coerce").to_numpy(), index=df["Date"]).dropna()
        s = s[~s.index.duplicated(keep="last")]
        out[t] = s
        all_dates.update(s.index.tolist())
    return out, pd.DatetimeIndex(sorted(all_dates))


def close_on_or_before(close_by_ticker: dict[str, pd.Series], ticker: str, d: pd.Timestamp, fallback: float) -> float:
    s = close_by_ticker.get(ticker)
    if s is None or s.empty:
        return fallback
    try:
        v = s.asof(pd.Timestamp(d))
        if pd.notna(v) and float(v) > 0:
            return float(v)
    except Exception:
        pass
    return fallback


def add_score_fields(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["final_score"] = pd.to_numeric(out["entry_signal_score"], errors="coerce")
    out["signal_threshold"] = pd.to_numeric(out["entry_signal_threshold"], errors="coerce")
    out["score_excess"] = out["final_score"] - out["signal_threshold"]
    out["s2_net"] = pd.to_numeric(out["s2_net"], errors="coerce")
    out["s2_hold"] = pd.to_numeric(out["s2_hold"], errors="coerce").clip(lower=1)
    out["s2_perday"] = out["s2_net"] / out["s2_hold"]
    out["s2_win"] = out["s2_net"] > 0
    out["s2_MAE"] = pd.to_numeric(out.get("s2_MAE", out.get("MAE")), errors="coerce")
    out["s2_MFE"] = pd.to_numeric(out.get("s2_MFE", out.get("MFE")), errors="coerce")
    out["split"] = out["split"].astype(str).str.upper()
    out["entry_date"] = pd.to_datetime(out["entry_date"], errors="coerce")
    out["s2_exit_date"] = pd.to_datetime(out["s2_exit_date"], errors="coerce")
    out["ticker"] = out["ticker"].astype(str).str.upper()
    return out


def corr_table(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for split in ["IS", "OOS"]:
        d = df[df["split"].eq(split)].copy()
        for score_col in ["final_score", "score_excess"]:
            for target_col in ["s2_net", "s2_perday", "s2_MFE", "s2_MAE"]:
                sub = d[[score_col, target_col]].dropna()
                if len(sub) < 3:
                    pearson = np.nan
                    spearman = np.nan
                else:
                    pearson = float(sub[score_col].corr(sub[target_col], method="pearson"))
                    spearman = float(sub[score_col].corr(sub[target_col], method="spearman"))
                rows.append({"split": split, "score_col": score_col, "target_col": target_col, "n": int(len(sub)), "pearson": pearson, "spearman": spearman})
            # win correlation as point-biserial via pearson with 0/1.
            sub = d[[score_col, "s2_win"]].dropna().copy()
            sub["win_num"] = sub["s2_win"].astype(int)
            rows.append({"split": split, "score_col": score_col, "target_col": "s2_win", "n": int(len(sub)), "pearson": float(sub[score_col].corr(sub["win_num"], method="pearson")) if len(sub) >= 3 else np.nan, "spearman": float(sub[score_col].corr(sub["win_num"], method="spearman")) if len(sub) >= 3 else np.nan})
    return pd.DataFrame(rows)


def assign_is_bins(df: pd.DataFrame, score_col: str, q: int = 5) -> tuple[pd.Series, list[float]]:
    is_vals = df.loc[df["split"].eq("IS"), score_col].dropna()
    edges = list(np.quantile(is_vals, np.linspace(0, 1, q + 1)))
    # make unique monotonic edges
    for i in range(1, len(edges)):
        if edges[i] <= edges[i - 1]:
            edges[i] = edges[i - 1] + 1e-12
    labels = [f"Q{i}_low" if i == 1 else (f"Q{i}_high" if i == q else f"Q{i}") for i in range(1, q + 1)]
    bins = pd.cut(df[score_col], bins=[-np.inf] + edges[1:-1] + [np.inf], labels=labels, include_lowest=True)
    return bins.astype(str), edges


def quintile_table(df: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, Any]]:
    out = df.copy()
    bins, edges = assign_is_bins(out, "final_score", 5)
    out["score_quintile"] = bins
    rows = []
    for split in ["IS", "OOS"]:
        d = out[out["split"].eq(split)].copy()
        for q, g in d.groupby("score_quintile", dropna=False):
            rows.append({
                "split": split,
                "score_quintile": str(q),
                "n": int(len(g)),
                "score_min": float(g["final_score"].min()),
                "score_max": float(g["final_score"].max()),
                "score_mean": float(g["final_score"].mean()),
                "excess_mean": float(g["score_excess"].mean()),
                "sum_net_pct": float(g["s2_net"].sum()),
                "avg_net_pct": float(g["s2_net"].mean()),
                "win_rate_pct": float(g["s2_win"].mean() * 100.0),
                "avg_holding_days": float(g["s2_hold"].mean()),
                "mean_net_per_day_pct": float(g["s2_perday"].mean()),
                "avg_MFE_pct": float(g["s2_MFE"].mean()),
                "avg_MAE_pct": float(g["s2_MAE"].mean()),
            })
    return pd.DataFrame(rows), {"final_score_is_edges": edges}


def cut_table(df: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, Any]]:
    is_excess = df.loc[df["split"].eq("IS"), "score_excess"].dropna()
    thresholds: dict[str, float] = {}
    rows = []
    for keep in CUT_KEEP_FRACS:
        if keep >= 1.0:
            cut = float(-np.inf)
            label = "keep_100pct"
        else:
            # keep top keep fraction -> threshold is 1-keep quantile of IS excess.
            cut = float(np.quantile(is_excess, 1.0 - keep))
            label = f"keep_{int(keep*100)}pct"
        thresholds[label] = cut
        for split in ["IS", "OOS"]:
            d0 = df[df["split"].eq(split)].copy()
            d = d0[d0["score_excess"] >= cut].copy()
            rows.append({
                "split": split,
                "cut_label": label,
                "keep_fraction_is_design": keep,
                "score_excess_cut_from_IS": cut if math.isfinite(cut) else None,
                "n": int(len(d)),
                "n_base": int(len(d0)),
                "kept_pct": float(len(d) / len(d0) * 100.0) if len(d0) else 0.0,
                "sum_net_pct": float(d["s2_net"].sum()),
                "avg_net_pct": float(d["s2_net"].mean()) if len(d) else np.nan,
                "win_rate_pct": float(d["s2_win"].mean() * 100.0) if len(d) else np.nan,
                "avg_holding_days": float(d["s2_hold"].mean()) if len(d) else np.nan,
                "mean_net_per_day_pct": float(d["s2_perday"].mean()) if len(d) else np.nan,
                "median_net_per_day_pct": float(d["s2_perday"].median()) if len(d) else np.nan,
                "avg_MDD_proxy_MAE_pct": float(d["s2_MAE"].mean()) if len(d) else np.nan,
            })
    return pd.DataFrame(rows), thresholds


def cluster_boot_diff_quintile(df: pd.DataFrame) -> pd.DataFrame:
    # Q5 high minus Q1 low for OOS; final_score quintiles already IS-defined.
    rng = np.random.default_rng(SEED)
    rows = []
    for split in ["IS", "OOS"]:
        d = df[df["split"].eq(split)].copy()
        q1 = d[d["score_quintile"].eq("Q1_low")]
        q5 = d[d["score_quintile"].eq("Q5_high")]
        for metric in ["s2_net", "s2_perday", "s2_win"]:
            if metric == "s2_win":
                q1_vals = q1[["candidate_id", metric]].copy(); q1_vals[metric] = q1_vals[metric].astype(float) * 100.0
                q5_vals = q5[["candidate_id", metric]].copy(); q5_vals[metric] = q5_vals[metric].astype(float) * 100.0
            else:
                q1_vals = q1[["candidate_id", metric]].dropna()
                q5_vals = q5[["candidate_id", metric]].dropna()
            clusters = sorted(set(d["candidate_id"].astype(str).unique()))
            q1_groups = {c: q1_vals.loc[q1_vals["candidate_id"].astype(str).eq(c), metric].to_numpy(dtype=float) for c in clusters}
            q5_groups = {c: q5_vals.loc[q5_vals["candidate_id"].astype(str).eq(c), metric].to_numpy(dtype=float) for c in clusters}
            vals = []
            for _ in range(N_BOOT):
                sampled = rng.choice(clusters, size=len(clusters), replace=True)
                a1 = np.concatenate([q1_groups[c] for c in sampled if len(q1_groups[c])]) if any(len(q1_groups[c]) for c in sampled) else np.array([np.nan])
                a5 = np.concatenate([q5_groups[c] for c in sampled if len(q5_groups[c])]) if any(len(q5_groups[c]) for c in sampled) else np.array([np.nan])
                vals.append(np.nanmean(a5) - np.nanmean(a1))
            lo, mid, hi = np.nanpercentile(vals, [2.5, 50, 97.5])
            obs = float((q5_vals[metric].mean() if len(q5_vals) else np.nan) - (q1_vals[metric].mean() if len(q1_vals) else np.nan))
            rows.append({"split": split, "comparison": "Q5_high_minus_Q1_low", "metric": metric, "observed": obs, "ci95_low": float(lo), "ci95_mid": float(mid), "ci95_high": float(hi), "clusters": len(clusters), "n_q1": int(len(q1_vals)), "n_q5": int(len(q5_vals))})
    return pd.DataFrame(rows)


def make_candidate_is_priority(df: pd.DataFrame) -> dict[str, float]:
    isdf = df[df["split"].eq("IS")].copy()
    # IS performance high priority: mean S2 net/day, tie by avg net.
    agg = isdf.groupby("candidate_id").agg(mean_perday=("s2_perday", "mean"), avg_net=("s2_net", "mean"), n=("s2_net", "size")).reset_index()
    # raw priority value for sorting desc.
    return agg.set_index("candidate_id")["mean_perday"].to_dict()


def prepare_oos_trades(df: pd.DataFrame) -> pd.DataFrame:
    d = df[df["split"].eq("OOS")].copy()
    d = d.dropna(subset=["entry_date", "s2_exit_date", "entry_price", "s2_exit_price", "s2_net"])
    d = d[(d["entry_date"] >= OOS_START) & (d["entry_date"] <= OOS_END)]
    d = d[d["s2_exit_date"] >= d["entry_date"]]
    return d


def simulate_priority(df: pd.DataFrame, priority_rule: str, close_by_ticker: dict[str, pd.Series], calendar: pd.DatetimeIndex, is_priority: dict[str, float]) -> tuple[pd.DataFrame, dict[str, Any], pd.DataFrame]:
    d = prepare_oos_trades(df)
    rng = np.random.default_rng(SEED)
    if priority_rule == "P1_score_high_first":
        d["priority"] = d["final_score"]
        ascending = [True, False, False, True]
        sort_cols = ["entry_date", "priority", "score_excess", "trade_row_id"]
    elif priority_rule == "P2_score_low_first":
        d["priority"] = d["final_score"]
        ascending = [True, True, True, True]
        sort_cols = ["entry_date", "priority", "score_excess", "trade_row_id"]
    elif priority_rule == "P3_random_seed42":
        d["priority"] = rng.random(len(d))
        ascending = [True, False, True]
        sort_cols = ["entry_date", "priority", "trade_row_id"]
    elif priority_rule == "P4_candidate_IS_perday_high_first":
        d["priority"] = d["candidate_id"].map(is_priority).fillna(-999.0)
        ascending = [True, False, False, True]
        sort_cols = ["entry_date", "priority", "final_score", "trade_row_id"]
    else:
        raise ValueError(priority_rule)
    d = d.sort_values(sort_cols, ascending=ascending).reset_index(drop=True)
    entries = {day: g.copy() for day, g in d.groupby("entry_date")}
    slots = [{"equity": 1.0 / K, "active": None} for _ in range(K)]
    accepted = 0
    skipped = 0
    accepted_rows = []
    curve_rows = []
    for day in calendar:
        day_entries = entries.get(day)
        acc_today = 0
        skip_today = 0
        if day_entries is not None and len(day_entries):
            free = [i for i, s in enumerate(slots) if s["active"] is None]
            for _, r in day_entries.iterrows():
                if free:
                    idx = free.pop(0)
                    slots[idx]["active"] = {"ticker": r["ticker"], "entry_price": float(r["entry_price"]), "exit_date": pd.Timestamp(r["s2_exit_date"]), "net_pct": float(r["s2_net"]), "entry_slot_equity": float(slots[idx]["equity"])}
                    accepted += 1
                    acc_today += 1
                    accepted_rows.append({"priority_rule": priority_rule, "accepted": True, "trade_row_id": int(r["trade_row_id"]), "candidate_id": r["candidate_id"], "ticker": r["ticker"], "entry_date": date_str(r["entry_date"]), "exit_date": date_str(r["s2_exit_date"]), "net_pct": float(r["s2_net"]), "final_score": float(r["final_score"]), "score_excess": float(r["score_excess"]), "priority": float(r["priority"])})
                else:
                    skipped += 1
                    skip_today += 1
        active_count = sum(1 for s in slots if s["active"] is not None)
        total = 0.0
        for s in slots:
            a = s["active"]
            if a is None:
                total += float(s["equity"])
                continue
            if pd.Timestamp(a["exit_date"]) <= day:
                val = float(a["entry_slot_equity"]) * (1.0 + float(a["net_pct"]) / 100.0)
                s["equity"] = val
                s["active"] = None
                total += val
            else:
                close = close_on_or_before(close_by_ticker, str(a["ticker"]), day, float(a["entry_price"]))
                total += float(a["entry_slot_equity"]) * (close / float(a["entry_price"]))
        curve_rows.append({"date": date_str(day), "priority_rule": priority_rule, "K": K, "equity": total, "active_count": active_count, "accepted_today": acc_today, "skipped_today": skip_today})
    curve = pd.DataFrame(curve_rows)
    curve["daily_return"] = curve["equity"].pct_change().fillna(0.0)
    perf = perf_metrics(curve, accepted, skipped, len(d), priority_rule)
    acc = pd.DataFrame(accepted_rows)
    if len(acc):
        perf.update({"accepted_avg_net_pct": float(acc["net_pct"].mean()), "accepted_win_rate_pct": float((acc["net_pct"] > 0).mean() * 100.0), "accepted_avg_final_score": float(acc["final_score"].mean()), "accepted_avg_score_excess": float(acc["score_excess"].mean())})
    return curve, perf, acc


def perf_metrics(curve: pd.DataFrame, accepted: int, skipped: int, total_signals: int, priority_rule: str) -> dict[str, Any]:
    eq = pd.to_numeric(curve["equity"], errors="coerce").ffill().fillna(1.0)
    ret = eq.pct_change().fillna(0.0)
    final = float(eq.iloc[-1]) if len(eq) else 1.0
    days = max(1, (pd.Timestamp(curve["date"].iloc[-1]) - pd.Timestamp(curve["date"].iloc[0])).days) if len(curve) else 1
    cagr = (final ** (365.0 / days) - 1.0) * 100.0 if final > 0 else -100.0
    dd = eq / eq.cummax() - 1.0
    mdd = float(dd.min() * 100.0) if len(dd) else 0.0
    std = float(ret.std(ddof=1))
    sharpe = float(ret.mean() / std * math.sqrt(TRADING_DAYS_PER_YEAR)) if std > 0 else 0.0
    active = pd.to_numeric(curve["active_count"], errors="coerce")
    return {"priority_rule": priority_rule, "K": K, "total_signals": int(total_signals), "realized_trades": int(accepted), "skipped_signals": int(skipped), "skip_rate_pct": float(skipped / total_signals * 100.0) if total_signals else 0.0, "final_multiplier": final, "CAGR_pct": cagr, "MDD_pct": mdd, "Sharpe_daily_ann": sharpe, "avg_active_positions": float(active.mean()), "max_active_positions": int(active.max()), "avg_slot_occupancy_pct": float(active.mean() / K * 100.0)}


def priority_portfolio(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    tickers = sorted(df[df["split"].eq("OOS")]["ticker"].unique())
    close_by_ticker, all_dates = load_close_data(tickers)
    max_exit = pd.to_datetime(df[df["split"].eq("OOS")]["s2_exit_date"], errors="coerce").max()
    sim_end = max(pd.Timestamp(max_exit), OOS_END)
    calendar = all_dates[(all_dates >= OOS_START) & (all_dates <= sim_end)]
    is_priority = make_candidate_is_priority(df)
    curves = []
    perfs = []
    accepted = []
    for rule in ["P1_score_high_first", "P2_score_low_first", "P3_random_seed42", "P4_candidate_IS_perday_high_first"]:
        curve, perf, acc = simulate_priority(df, rule, close_by_ticker, calendar, is_priority)
        curves.append(curve)
        perfs.append(perf)
        accepted.append(acc)
        print(f"[PORT] {rule} CAGR={perf['CAGR_pct']:.2f} MDD={perf['MDD_pct']:.2f} Sharpe={perf['Sharpe_daily_ann']:.2f} skip={perf['skip_rate_pct']:.2f}", flush=True)
    return pd.concat(curves, ignore_index=True), pd.DataFrame(perfs), pd.concat(accepted, ignore_index=True)


def judge_a(corr: pd.DataFrame, qdiff: pd.DataFrame, qt: pd.DataFrame) -> str:
    oos_corr = corr[(corr["split"].eq("OOS")) & (corr["score_col"].eq("final_score")) & (corr["target_col"].eq("s2_net"))]
    oos_win_corr = corr[(corr["split"].eq("OOS")) & (corr["score_col"].eq("final_score")) & (corr["target_col"].eq("s2_win"))]
    qnet = qdiff[(qdiff["split"].eq("OOS")) & (qdiff["metric"].eq("s2_net"))]
    qwin = qdiff[(qdiff["split"].eq("OOS")) & (qdiff["metric"].eq("s2_win"))]
    rho = float(oos_corr["spearman"].iloc[0]) if len(oos_corr) else 0.0
    wrho = float(oos_win_corr["spearman"].iloc[0]) if len(oos_win_corr) else 0.0
    net_low = float(qnet["ci95_low"].iloc[0]) if len(qnet) else 0.0
    net_high = float(qnet["ci95_high"].iloc[0]) if len(qnet) else 0.0
    win_low = float(qwin["ci95_low"].iloc[0]) if len(qwin) else 0.0
    win_high = float(qwin["ci95_high"].iloc[0]) if len(qwin) else 0.0
    if rho > 0.02 and wrho > 0.0 and (net_low > 0 or win_low > 0):
        return "SCORE_PREDICTS"
    if rho < -0.02 and wrho < 0.0 and (net_high < 0 or win_high < 0):
        return "SCORE_INVERSE"
    return "SCORE_NEUTRAL"


def judge_c(port: pd.DataFrame) -> str:
    p = port.set_index("priority_rule")
    p1 = p.loc["P1_score_high_first"]
    p2 = p.loc["P2_score_low_first"]
    p3 = p.loc["P3_random_seed42"]
    if p1["CAGR_pct"] > p3["CAGR_pct"] and p1["Sharpe_daily_ann"] > p3["Sharpe_daily_ann"]:
        return "PRIORITY_BY_SCORE_HELPS"
    if p2["CAGR_pct"] > p1["CAGR_pct"] and p2["CAGR_pct"] > p3["CAGR_pct"]:
        return "PRIORITY_INVERSE"
    return "PRIORITY_SCORE_NO_EDGE"


def main() -> int:
    started = time.time()
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    PERSIST_DIR.mkdir(parents=True, exist_ok=True)
    raw = pd.read_csv(TRADE_PATH)
    if "trade_row_id" not in raw.columns:
        raw = raw.reset_index(drop=False).rename(columns={"index": "trade_row_id"})
    df = add_score_fields(raw)
    df.to_csv(OUT_DIR / "score_trade_input_s2.csv", index=False, float_format="%.12g", lineterminator="\n")
    corr = corr_table(df)
    corr.to_csv(OUT_DIR / "score_correlations.csv", index=False, float_format="%.12g", lineterminator="\n")
    qt, bin_info = quintile_table(df)
    # attach quintile to df for qdiff.
    bins, _edges = assign_is_bins(df, "final_score", 5)
    df["score_quintile"] = bins
    qt.to_csv(OUT_DIR / "score_quintile.csv", index=False, float_format="%.12g", lineterminator="\n")
    qdiff = cluster_boot_diff_quintile(df)
    qdiff.to_csv(OUT_DIR / "score_quintile_bootstrap_diff.csv", index=False, float_format="%.12g", lineterminator="\n")
    cuts, cut_info = cut_table(df)
    cuts.to_csv(OUT_DIR / "threshold_cuts.csv", index=False, float_format="%.12g", lineterminator="\n")
    curves, priority_perf, accepted = priority_portfolio(df)
    curves.to_csv(OUT_DIR / "priority_equity_curves.csv", index=False, float_format="%.12g", lineterminator="\n")
    priority_perf.to_csv(OUT_DIR / "priority_portfolio.csv", index=False, float_format="%.12g", lineterminator="\n")
    accepted.to_csv(OUT_DIR / "priority_accepted_trades.csv", index=False, float_format="%.12g", lineterminator="\n")
    verdict_a = judge_a(corr, qdiff, qt)
    verdict_c = judge_c(priority_perf)
    summary = {"created_at": datetime.now().isoformat(timespec="seconds"), "seed": SEED, "n_boot": N_BOOT, "verdict_a": verdict_a, "verdict_c": verdict_c, "input": str(TRADE_PATH), "ohlc_snapshot_dir": str(SNAP_DIR), "out_dir": str(OUT_DIR), "persist_dir": str(PERSIST_DIR), "rows": {"all": int(len(df)), "IS": int((df['split']=='IS').sum()), "OOS": int((df['split']=='OOS').sum())}, "score_columns": {"final_score": "entry_signal_score", "signal_threshold": "entry_signal_threshold", "score_excess": "entry_signal_score - entry_signal_threshold"}, "bin_info": bin_info, "cut_info": cut_info, "priority_rules": {"P1": "final_score high first", "P2": "final_score low first", "P3": "random seed=42", "P4": "candidate IS mean S2 net/day high first"}, "elapsed_sec": round(time.time() - started, 3)}
    (OUT_DIR / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    readout = []
    readout.append("# Score ↔ performance and priority rule validation")
    readout.append("")
    readout.append(f"- verdict A: **{verdict_a}**")
    readout.append(f"- verdict C: **{verdict_c}**")
    readout.append(f"- input: `{TRADE_PATH}`")
    readout.append(f"- OHLC: `{SNAP_DIR}`")
    readout.append(f"- rows: all={len(df)}, IS={(df['split']=='IS').sum()}, OOS={(df['split']=='OOS').sum()}")
    readout.append("- final_score = `entry_signal_score`; score_excess = `entry_signal_score - entry_signal_threshold`.")
    readout.append("")
    readout.append("## A. Correlations")
    readout.append(corr.to_markdown(index=False))
    readout.append("")
    readout.append("## A. Score quintiles, IS-defined bins")
    readout.append(qt.to_markdown(index=False))
    readout.append("")
    readout.append("## A. Q5 high minus Q1 low bootstrap")
    readout.append(qdiff.to_markdown(index=False))
    readout.append("")
    readout.append("## B. Threshold excess cuts, IS-defined")
    readout.append(cuts.to_markdown(index=False))
    readout.append("")
    readout.append("## C. S2 K=20 priority portfolio")
    readout.append(priority_perf.to_markdown(index=False))
    readout.append("")
    readout.append("## Files")
    for fn in ["readout.md", "score_correlations.csv", "score_quintile.csv", "score_quintile_bootstrap_diff.csv", "threshold_cuts.csv", "priority_portfolio.csv", "priority_equity_curves.csv", "priority_accepted_trades.csv", "summary.json"]:
        readout.append(f"- `{OUT_DIR / fn}`")
        readout.append(f"- `{PERSIST_DIR / fn}`")
    (OUT_DIR / "readout.md").write_text("\n".join(readout) + "\n", encoding="utf-8")
    for p in OUT_DIR.iterdir():
        if p.is_file():
            shutil.copy2(p, PERSIST_DIR / p.name)
    print("DONE", flush=True)
    print("VERDICT_A", verdict_a, flush=True)
    print("VERDICT_C", verdict_c, flush=True)
    print("OUT_DIR", OUT_DIR, flush=True)
    print("PERSIST_DIR", PERSIST_DIR, flush=True)
    print("ELAPSED_SEC", round(time.time() - started, 3), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
